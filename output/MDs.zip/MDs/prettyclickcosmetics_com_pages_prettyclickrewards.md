✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

# Prettyclick Rewards

Prettyclick Reward Points is a loyalty program offered by Prettyclick, a beauty and cosmetics company, to thank their loyal customers for their patronage. Here's how it works:

- Earning Points: Customers can earn reward points by making purchases at Prettyclick locations or through online orders. For every 100 Rupees spent at any Prettyclick location, customers earn 5 reward points. However, for online orders, points are credited only after the payment is made.

Earning Points: Customers can earn reward points by making purchases at Prettyclick locations or through online orders. For every 100 Rupees spent at any Prettyclick location, customers earn 5 reward points. However, for online orders, points are credited only after the payment is made.

- Free Program: The Prettyclick Rewards program is free to join. Customers do not have to pay any membership fees or sign-up charges to participate.

Free Program: The Prettyclick Rewards program is free to join. Customers do not have to pay any membership fees or sign-up charges to participate.

- Exclusive Offers: As a member of the Prettyclick Rewards program, customers can expect to receive exclusive offers via email and push notifications. These offers are a way of showing appreciation to loyal customers and may include discounts, promotions, or other incentives.

Exclusive Offers: As a member of the Prettyclick Rewards program, customers can expect to receive exclusive offers via email and push notifications. These offers are a way of showing appreciation to loyal customers and may include discounts, promotions, or other incentives.

- Earning Points on Every Purchase: Customers can earn reward points on every purchase they make at Prettyclick locations, which encourages repeat business and loyalty.

Earning Points on Every Purchase: Customers can earn reward points on every purchase they make at Prettyclick locations, which encourages repeat business and loyalty.

- Online Purchases: Customers can also earn reward points when buying from prettyclickcosmetics.com, the company's online platform. However, as mentioned earlier, points are credited only after the payment for the online order is made.

Online Purchases: Customers can also earn reward points when buying from prettyclickcosmetics.com, the company's online platform. However, as mentioned earlier, points are credited only after the payment for the online order is made.

- Expiration:The Reward Points will expire every one year if the account is inactive. So to activate your account, stock in your favorite products!

In summary, Prettyclick Reward Points is a customer loyalty program that allows customers to earn points for their purchases at Prettyclick stores and online. These points can lead to exclusive offers and incentives as a way of thanking customers for their continued support.

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.