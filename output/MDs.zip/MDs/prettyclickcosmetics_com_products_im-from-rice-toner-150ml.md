✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

# I'm From Rice Toner 150ml

## I'm From Rice Toner 150ml

Vendor:I'm From

Type:Toner

Earn 5% prettyclick reward points on every purchase

- 100% Authentic

- HYDRATION & LUMINOSITY BOOST: Improves hydration and moisture barrier with an illuminating effect, enhancing your skin's natural radiance. Balances oil and water levels for a harmonized and refreshed complexion.

- NOURISHING RICE EXTRACT FORMULA: Contains 77.78% Goami rice extract and a blend of four vegetable-originated extracts. Soothes flaky dead skin cells by forming a moisture protective layer, while Sirtuin from rice protects against sun damage and relieves skin stress.

- PURE & POTENT GOAMI RICE: Sourced from Yeoju, Korea, Goami rice is rich in hemicellulose and cultivated in a clean environment with abundant water and fertile soil.

- PROTECTIVE BARRIER & LUSTER: Forms a protective barrier, preventing water loss and eliminating dead skin cells. Provides luster and moisturization, rejuvenating dry and tired skin for a revitalized look.

- DOUBLE-LAYER MOISTURIZATION: Shake well to mix the water and emulsion layers. The milky texture ensures deeper moisturization and nourishment, offering elasticity care with 77.78% rice extract. Suitable for all skin types, including oily, sensitive, dry, and combination skin.

- Free Delivery for orders over Rs 3500

- Exchange within 7 days if the sealed is not opened

### I'm From Rice Toner 150ml

## Customer Reviews

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick