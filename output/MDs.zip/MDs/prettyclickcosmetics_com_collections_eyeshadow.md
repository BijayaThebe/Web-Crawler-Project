✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

38 products

## Filter

- In stock28

- Out of stock15

- In stock28

- Out of stock15

Eyeshadow

### L.A. Girl Keep it Playful Eyeshadow

### Choose your option

Eyeshadow

### L.A. Colors Color Block 10 Color Eyeshadow Palette

### Choose your option

Eyeshadow

### L.A.  Colors 14 Color Eyeshadow Palette

### Choose your option

Eyeshadow

### L.A. Colors Spill The Tea Eyeshadow

### Choose your option

Eyeshadow

### L.A. Colors 12 Colors Too Precious Eyeshadow

### Choose your option

Eyeshadow

### Kara Beauty 5 Color Eyeshadow Palette- lost in oasis

### Choose your option

Eyeshadow

### L.A. Colors What's The Tea Eyeshadow

### Choose your option

Eyeshadow

### Kara Beauty Party Girl Eyeshadow Palette

### Choose your option

Eyeshadow

### Kara Like Totally Pro Shadow Palette

### Choose your option

Eyeshadow

### The Balm Gold Coast Face Palette

### Choose your option

Eyeshadow

### Wet N Wild Glitter Single

### Choose your option

Eyeshadow

### Beauty Creations Riding Solo Single Pressed Shadow

### Choose your option

Eyeshadow

### L.A. Girl Pro Mastery Eyeshadow Palette

### Choose your option

Eyeshadow

### J. Cat Beauty Shimmie Struck Shadow Stick-Mesmer Eyes

### Choose your option

Eyeshadow

### L.A. Girl 12 Color Nudes Eyeshadow (12g)

### Choose your option

Eyeshadow

### The Balm 12 Shade Miss Nude York Eyeshadow Pallette

### Choose your option

Eyeshadow

### Bellapierre Cosmetics Satin Rose Eye And Face Book

### Choose your option

Eyeshadow

### L.A.  Colors 12 Piece Eyeshadow Pallette

### Choose your option

Eyeshadow

### Beauty Creations Nude X Mini Shadow Palette 8.5g

### Choose your option

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick