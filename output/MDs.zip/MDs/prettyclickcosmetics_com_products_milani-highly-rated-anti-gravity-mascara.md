✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

# Milani Highly Rated Anti Gravity Mascara - 115

## Milani Highly Rated Anti Gravity Mascara - 115

Vendor:Milani

Type:Mascara

Earn 5% prettyclick reward points on every purchase

- 100% Authentic

Available in stock

Prepare for lash lift-off! Milani’s Highly Rated Anti-Gravity Mascara instantly delivers extreme volume, length and lift for truly out of this world lashes. Infused with nourishing Castor Oil, the intense black formula applies seamlessly without clumping or smudging for up to 24 hours of flawless wear. The flexible, molded hourglass shaped brush coats and grabs every lash for maximum impact every time.

93% of consumers saw extreme volume & instant lift*

90% of consumers saw instant length*

Up to 24HR wear

Intense black formula applies seamlessly without clumping or smudging

Hourglass-shaped, molded brush coats every lash

Enhanced with Castor Oil and plant and fruit-based waxes

*Results observed in a consumer panel survey

- Free Delivery for orders over Rs 3500

- Exchange within 7 days if the sealed is not opened

### Milani Highly Rated Anti Gravity Mascara - 115

## Customer Reviews

Not bad

i just love the way it looked, it is so light weighted even after 3-4 coats.. instant length & volume... easy to wear and easy to remove..

awesome love it❤️

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick