- OSHC

- STUDENT ACCOMMODATION

- NEWS & OFFER

- COUNSELOR DASHBOARD

- LOGINSTUDENT LOGIN

- STUDENT LOGIN

## Connect. Learn. Succeed. With Chisholm Institute!

## EventDetails

### September 8, 2025, Monday

### KIEC Avenue 44-05, Lalupatey Marg, Putalisadak, KTM, Nepal

🌟 Your UK Study Journey Starts Here!✨

KIEC proudly invites you to an exclusive session with Mr. Prashant Prasanna, Manager – International Student Recruitment & Admissions at Chisholm Institute.

This is your chance to learn everything about:✅ Programs & courses at Chisholm✅ Admission requirements & application process✅ Scholarships and opportunities for international students✅ Campus life in Australia

🗓️ Date: Monday, September 8, 2025⏰ Time: 12:00 PM – 1:00 PM

𝐅𝐨𝐫 𝐦𝐨𝐫𝐞 𝐝𝐞𝐭𝐚𝐢𝐥𝐬, 𝐯𝐢𝐬𝐢𝐭 𝐮𝐬 𝐚𝐭:KIEC Avenue44-05, Lalupatey Marg, Putalisadak, KTM, Nepal📞 +977 4531221, 01 4516197📍 https://bit.ly/KIEC_Avenue📩[email protected]

If you cannot attend this session, please visit nearest KIEC offices

𝐅𝐨𝐫 𝐛𝐫𝐚𝐧𝐜𝐡𝐞𝐬, 𝐲𝐨𝐮 𝐜𝐚𝐧 𝐯𝐢𝐬𝐢𝐭:🌐 www.kiec.edu.np/contact-us

Don’t miss this opportunity to connect directly with the representative and take the first step toward your study journey in Australia! 🎓✈️

# ChisholmInstitute #StudyInAustralia #MeetTheRepresentative #KIECNepal #StudyAbroad #FutureIsBright