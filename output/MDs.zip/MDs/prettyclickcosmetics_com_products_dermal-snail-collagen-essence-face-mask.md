✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

# Dermal Snail Collagen Essence Face Mask

## Dermal Snail Collagen Essence Face Mask

Vendor:Dermal

Type:Face mask

Earn 5% prettyclick reward points on every purchase

- 100% Authentic

Available in stock

Dermal Snail Collagen Essence Face Mask contains snail mucin firms and restores skin by replenishing moisture and supporting cell regeneration which helps fade acne scars, reduce uneven complexions, reduce hyperpigmentation & increases blood circulation. Essential nutrients & antioxidants present in the mask protect the skin from the harmful effects of the free radicals and reverse the appearance of wrinkles and dark spots lighten the skin tone keep it moist & bright. It is a pure essence facial mask that is specially formulated with highly concentrated active ingredients that penetrate the skin effectively to deliver essential nutrients.

#### Features & Benefits:

- Detoxifies skin & gives a flawless appearance

- Have a bright, soft, and rejuvenated skin in 15 minutes.

- Reduce Fine lines, wrinkles & age spots.

- Hydrolyzed Collagen & Vitamins provides your tired skin nutrition and keep your skin healthy and bright whole day.

- Dermal masks moisturize skin and maintain skin elasticity.

- It leaves skin feeling soft, refreshed and perfectly hydrated.

- It helps to revitalize and soothe the skin with a mild astringent effect of aloe extracts.

- Easy to use sheet mask.

- Free from Mineral Oils, Sulphates, PEG & PG, Hypoallergenic.

- Dermatologically Tested.

- Recommended for all skin type.

- It Can Use 3 times a week for good results.

- Made in Korea.

#### How to use:

STEP 1- After cleansing, dry face and soothe your face with toning waterSTEP 2-Take out the mask sheet from the pack and unfold it.STEP 3-First, gently apply the mask sheet around your eye part and then fit your face contoursSTEP 4-Leave on for 15~20 minutes.STEP 5-Peel off the mask sheet and tap the remaining collagen essence over your face until it completely absorbs to your skin.

You canUSE AS COLDby keeping in the refrigerator orUSE AS WARMby soaking about 2~3 minutes in warm water.

#### Additional Product Feature:

- You can feel the difference after every application.

- After application, avoid face wash, let essence should remain on skin for a long time for better results.

- Dermal masks also contain Hydrolyzed Collagen, Vitamin E, C which keeps your tired skin relaxed, healthy, moistened and elastic.

#### Caution:

- Stop using if skin becomes red, swollen itchy and etc during and after use.

- Avoid using on the irritated or sunburned skin by direct sunlight.

- Stop using on troubled skin part including eczema or dermatitis.

- Avoid contact with the eyes, if contact occurs rinses eyes thoroughly with water.

- For preventing dryness, use soon after opening.

- Keep away from the reach of baby and children.

- Stored at room temperature only. Keep away from direct sunlight.

- Free Delivery for orders over Rs 3500

- Exchange within 7 days if the sealed is not opened

### Dermal Snail Collagen Essence Face Mask

## Customer Reviews

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick