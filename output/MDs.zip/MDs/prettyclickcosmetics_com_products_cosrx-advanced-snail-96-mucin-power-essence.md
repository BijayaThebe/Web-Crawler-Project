✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

# Cosrx Advanced Snail 96 Mucin Power Essence

## Cosrx Advanced Snail 96 Mucin Power Essence

Vendor:Cosrx

Type:Power Essence

Earn 5% prettyclick reward points on every purchase

- 100% Authentic

Available in stock

Letter of  Authentication

BENEFITS

• Fades dark spots• Improves skin texture• Anti-aging• Intense hydration

TARGETS

• Dull & rough skin• Soothing damaged skin• Dark spots & scars

HOW TO USE

After cleansing and toning, apply a small amount on your entire face. Gently pat using fingertips to aid absorption, and then go forth with your moisturizer

### Authorized Distributor letter

- Free Delivery for orders over Rs 3500

- Exchange within 7 days if the sealed is not opened

### Cosrx Advanced Snail 96 Mucin Power Essence

## Customer Reviews

hydrating  and healing

The texture is so smooth

It’s very hydrating

It's so good. It make your skin soft and hydrated.😊😊

Make skin soft and glow

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick