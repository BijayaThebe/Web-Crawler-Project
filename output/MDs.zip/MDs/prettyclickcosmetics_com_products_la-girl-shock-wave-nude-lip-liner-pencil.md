✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

# L.A. Girl Shockwave Nude Lip Liner Pencil

## L.A. Girl Shockwave Nude Lip Liner Pencil

Vendor:La Girl

Type:Lipliner

Earn 5% prettyclick reward points on every purchase

- 100% Authentic

Available in stock

You might want to take a seat before you swatch, because the Shockwave Lipliners will have you shook. Shockingly bold colors glide on creamy pigment with a full coverage finish that lasts up to 8 hours. Electrify your look with a vivid, statement lip from the Neon collection, or find your nude go-to lipliner from the Nude collection that will literally complement any look. The soft plastic pencil can be sharpened with a regular sharpener for precise application every time. Get ready to create looks that shock.

- Smudge-proof glide on gel lipliner

- Available in neon or nude finishes

- Up to 8-hour wear

- Water-resistant

- Soft plastic can be sharpened

- Cruelty-free & paraben-free

### How to Apply

Line top and bottom lip, following as close as possible to your natural lip line.

Fill in lips with the lipliner, or your favorite lipstick.

Sharpen as needed.

- Free Delivery for orders over Rs 3500

- Exchange within 7 days if the sealed is not opened

### L.A. Girl Shockwave Nude Lip Liner Pencil

## Customer Reviews

La Girl Shock Wave Nude Lip Liner Pencil

best lipliner i've purchased :)

La Girl Shock Wave Nude Lip Liner Pencil

Highly pigmented and glides very smoothly on your lips. Definitely gonna repurchase it!

La Girl Shock Wave Nude Lip Liner Pencil

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick