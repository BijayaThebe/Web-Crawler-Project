- OSHC

- STUDENT ACCOMMODATION

- NEWS & OFFER

- COUNSELOR DASHBOARD

- LOGINSTUDENT LOGIN

- STUDENT LOGIN

## Exclusive Session with the University of Waikato

## EventDetails

### 15th September 2025, Monday

### KIEC Avenue 44-05, Lalupatey Marg, Putalisadak, KTM, Nepal

KIEC invites you to an exclusive session with Ms. Nidhi Chugh, Student Recruitment Manager at the University of Waikato College, a leading pathway provider to the prestigious University of Waikato – ranked among the world’s top universities. 🎓🌏

This is your golden chance to explore:✅ World-class programs and career-focused courses✅ Scholarships and financial aid opportunities✅ Application process and entry requirements✅ Campus life and student support in New Zealand

🗓️ Date: Monday, 15th September 2025⏰ Time: 11:30 AM – 12:30 PM

𝐅𝐨𝐫 𝐦𝐨𝐫𝐞 𝐝𝐞𝐭𝐚𝐢𝐥𝐬, 𝐯𝐢𝐬𝐢𝐭 𝐮𝐬 𝐚𝐭:KIEC Avenue44-05, Lalupatey Marg, Putalisadak, KTM, Nepal📞 +977 4531221, 01 4516197📍 https://bit.ly/KIEC_Avenue📩[email protected]

If you cannot attend this session, please visit nearest KIEC offices

𝐅𝐨𝐫 𝐛𝐫𝐚𝐧𝐜𝐡𝐞𝐬, 𝐲𝐨𝐮 𝐜𝐚𝐧 𝐯𝐢𝐬𝐢𝐭:🌐 www.kiec.edu.np/contact-us

Don’t miss this opportunity to connect directly with the representative and take the next step toward your study journey in New Zealand! ✈️✨

# UniversityOfWaikatoCollege #StudyInNZ #Scholarships #InternationalStudents #KIECNepal #FutureIsBright #StudyAbroad