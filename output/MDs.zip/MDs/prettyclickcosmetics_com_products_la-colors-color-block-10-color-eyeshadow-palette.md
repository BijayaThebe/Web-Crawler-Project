✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

# L.A. Colors Color Block 10 Color Eyeshadow Palette

## L.A. Colors Color Block 10 Color Eyeshadow Palette

Vendor:LA COLORS

Type:Eyeshadow

Earn 5% prettyclick reward points on every purchase

- 100% Authentic

Out of stock

Color Block eyeshadow palettes deliver multiple looks in one compact. Two oversized pans of the most used highlighting colors perfectly paired with 4 lid and 4 crease shades in each palette. Intuitive pan pressing makes it easy to create stunning NUDE, ROSE, or COOL eye looks.

- Free Delivery for orders over Rs 3500

- Exchange within 7 days if the sealed is not opened

### L.A. Colors Color Block 10 Color Eyeshadow Palette

## Customer Reviews

Satisfied with this product !!

LOVE THE WAY IT STAYS LONG AND BEAUTIFUL

Very satisfied ❤️❤️

I bought the glam pallete and it is too good. It's pigmented and has perfect nude shades 😊.

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick