- SERVICESRelaxation MassageSignature MassageTherapeutic MassageMini TherapyLadies Beauty ServicesGentlemen Salon ServicesVastiCuppingHydroTherapy

- PACKAGESBeauty PackageSpa PackageSeasonal Package

- MEMBERSHIPSolatee MembershipTranquility Wellness Card

- ABOUTWelcome To Tranquility SpaHistoryMission And VisionTeams

- OUTLETSThe Soaltee KathmanduHotel Radission KathmanduChandragiri Hills ResortHotel SarowarHotel Crown ImperialHotel ShankerTranquility Spa - JhamsikhelKupondole

- BLOGS

- CAREERS

- CONTACT

# OUR SERVICES

##### Starting From Rs
                    6000-10000/-

##### Starting From Rs
                    2500-3500/-

##### Starting From Rs
                    3000-15000/-

##### Starting From Rs
                    4500-12000/-

##### Starting From Rs
                    400-15000/-

##### Starting From Rs
                    1500-28000/-

##### Starting From Rs
                    3500-10000/-

##### Starting From Rs
                    4500-6000/-

##### Starting From Rs
                    700-7000/-

##### Starting From Rs
                    7000-13000/-

#### Our Associated Partners