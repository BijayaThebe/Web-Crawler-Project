## Tranquility Spa at Ramada by Wyndham Kathmandu Dhumbarahi

## We're delighted to have you here.

Stay connected with us for the latest spa updates, special offers, and wellness tips.

- SERVICESRelaxation MassageSignature MassageTherapeutic MassageMini TherapyLadies Beauty ServicesGentlemen Salon ServicesVastiCuppingHydroTherapy

- PACKAGESBeauty PackageSpa PackageSeasonal Package

- MEMBERSHIPSolatee MembershipTranquility Wellness Card

- ABOUTWelcome To Tranquility SpaHistoryMission And VisionTeams

- OUTLETSThe Soaltee KathmanduHotel Radission KathmanduChandragiri Hills ResortHotel SarowarHotel Crown ImperialHotel ShankerTranquility Spa - JhamsikhelKupondole

- BLOGS

- CAREERS

- CONTACT

# NEPAL’S LARGEST SPA CHAIN

We are the first Day Spa to be established in Nepal and recognized by Nepal Tourism Board and we are also the first Nepalese brand to expand its service in the international market. Our chain of spas are managed by experienced and professional experts educated in renowned institute in Thailand, Switzerland, UAE, Australia and India with a proven history in providing an excellent service at Marriott Putrajaya, Palm Garden Hotel Malaysia, Mirage Lords Inn, Le Meridien, Hyatt, Radisson, Shangri~La and Intercontinental Hotel Group.

Experience ultimate rejuvenation at our spa, where serenity and expertise unite.

100PACKAGES

2M+HAPPY GUESTS

10OUTLETS

# Let's Dive Into Our Services.

#### Massage Therapy

#### Beauty Therapy

#### Hydrotherapy

#### Yoga

#### Gym

# Find Your Memberships-Let's connect through our
                        membership program

# Special Offers

No special
                            offers available at the moment.

# Hear from Our Clients

I had one of the best service overall. All the staffs are well trained and co-operative. I took my massage session with deep and she was really good. Thank you Tranquility Spa for exceptional service.

# Subekshya Khadka

Customer

Sandipa my therapist was excellent. The techniques are perfect and the spa is an experience you must not miss.

# Bhagyashree Dassani

Customer

The service here is absolutely great, and all the staff are very friendly. Thank you!

# Preeti Rai

Customer

The service at Tranquility Spa was absolutely wonderful. Thank you so much, Tranquility Spa, for the service. I would love to come back for the service.

# Sabitra Bhandari (Samba)

Customer

# Be Skilled , Be Independent
                        withTIBSA !

#### Our Associated Partners