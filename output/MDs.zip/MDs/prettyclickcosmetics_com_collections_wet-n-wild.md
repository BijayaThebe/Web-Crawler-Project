✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

58 products

## Filter

- In stock47

- Out of stock22

- In stock47

- Out of stock22

Palette

### Wet n Wild Megaglo Contour Palette - Dulce De Leche

### Choose your option

Brow Gel

### Wet n Wild Mega Stay Extreme Hold Brow Gel 5.6ml

### Choose your option

Highlighter

### Wet n Wild Megaglo Vitamin E Makeup Highlight Stick 6 g

### Choose your option

primer

### Wet n Wild Prime Focus Primer Serum 30ml

### Choose your option

Lip Liner

### Wet n Wild Perfect Pout Lip Liner Stain 0.5ml

### Choose your option

Foundation

### Wet n Wild Photo Focus Matte Foundation

### Choose your option

corrector

### Wet N Wild Photo Focus Care Color Corrector

### Choose your option

Liquid Eyeliner

### Wet n Wild Breakup Proof Liquid Eyeliner - 0.9 ml

### Choose your option

Lip Balm

### Lippy Pals Unicorn Frosting

### Choose your option

Lip Oil

### Wet n Wild Lip Oil 7.11ml

### Choose your option

Lipstick

### Wet n Wild Megalast Matte Lipstick

### Choose your option

Mascara

### Wet n Wild Big Poppa Mascara 10ml

### Choose your option

Lip Mousse

### Wet n Wild Cloud Pout Marshmallow Lip Mousse - 3 ml

### Choose your option

Concealer

### Wet N Wild Megalast Incognito All Day Full Coverage Concealer

### Choose your option

Eyeshadow

### Wet n Wild Eyeshadow Single

### Choose your option

Brush

### Wet n Wild Large Eyeshadow Brush

### Choose your option

Brow

### Wet n Wild Ultimate Brow Kit Ash Brown

### Choose your option

Powder

### Wet n Wild Megaglo Highlighting Powder - 5.4 g

### Choose your option

Powder

### Wet n Wild Bare Focus Clarifying Finishing Powder

### Choose your option

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick