✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

# I'm From Rice Serum 30ml

## I'm From Rice Serum 30ml

Vendor:I'm From

Type:Serum

Earn 5% prettyclick reward points on every purchase

- 100% Authentic

- EVITALIZE YOUR SKIN WITH RADIANCE! Infused with gamma-orizanol from rice buds and niacinamide, our serum brings vitality to dull skin, leaving it clean and refreshed.

- DEEP MOISTURIZATION FOR LASTING HYDRATION! Packed with rice bud extract and hyaluronic acid, this serum captures moisture from deep within, providing your skin with a hydrating and nourishing boost.

- LIGHTWEIGHT AND REFRESHING! Experience an immediate melt into your skin with our serum's light and refreshing texture, leaving behind a moist finish for a revitalized complexion.

- SAFE AND GENTLE FORMULATION! Dermatologically tested for skin irritation and crafted with non-GMO ingredients, our serum ensures a safe and pleasant skincare experience for all.

- ENHANCE THE EFFECT WITH THE RICE LINE! Maximize the benefits by using our serum in combination with other I'm from rice line products. With 73% Rice Germ Fermented Extract, it retains over 65% of rice's nutritional value, promoting collagen production and improving skin elasticity. For optimal results, pair it with our rice cream for a double-effect skincare routine.

- Free Delivery for orders over Rs 3500

- Exchange within 7 days if the sealed is not opened

### I'm From Rice Serum 30ml

## Customer Reviews

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick