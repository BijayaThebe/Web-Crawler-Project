✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

# Privacy Policy

## Privacy Policy

- INTRODUCTION

This Privacy Policy ("Policy") describes the type of personal information we collect from our User, purpose for collecting such information, how we use it, with whom we share it and the choices available to our customers regarding our use of the information. We will not disclose the personal information and sensitive information (meanings ascribed in clause 2 below) shared by the user other than in compliance with this Policy. If you do not consent to any of the terms enumerated in this Policy, do not proceed to use the Site.

Our Policy is subject to change at any time without notice. Your continued use of the Site following such changes to the Policy constitutes your acceptance of the changed Policy and to be bound by such changes. If you do not continue to use the Site following change in the policy but take no action with respect to your personal information and sensitive information with us, our use of your personal information and sensitive information shall remain subject to the Policy in effect prior to the change. You are responsible for periodically reviewing this Policy in order to be aware of any changes thereto.

2. WHAT WE COLLECT

We may collect personal identifiable information from you when you save or otherwise provide us when you set up a free account with the Site OR when you communicate with us via phone, email, chat, etc. OR when you fill an entry to participate in any contest, promotion or survey, etc. OR use the service of Gift Card on the Site OR when you participate at one of our events, etc. As a result of these actions you might supply us with personal information, such as your name, e-mail and postal addresses, phone number(s), credit card information, names of people to whom purchases have been shipped including address and telephone numbers, IP addresses, product interest information and in certain circumstances, your opinions and individual preferences, etc. (collectively "Personal Information"). When you visit this Site, our social media platforms, or our social networking or mobile applications, may also collect certain information about your device or usage by automated means or by using technologies such as cookies, web server logs and web beacons.

You may also provide us with information like financial information such as Bank account or credit card or debit card or other payment instrument details, password, physical health condition; medical history, sex, etc. (collectively "Sensitive Information") for availing the services at our Site.

We may also maintain a record of your product interests and acquire information about you from our present and/or future affiliates.

This Site is directed to be used by adults only who are above the age of 18 years. If you are not an adult, while you may look at our Site, but you should not make a purchase, register, or submit personal information to us. Minors should not be using the Site with any personal information. In an event of default by the minor, the parent or the guardian will be liable to compensate for whatsoever damages arising out of such wrongful use by the minor.

3. WHAT IS THE PURPOSES FOR WHICH THE PERSONAL AND SENSITIVE INFORMATION ARE COLLECTED

PrettyClick Cosmetics may use your collected Personal Information in the following cases:

- Send you or your friends, relatives or associates, the products that you have ordered

- Process your Gift Card transaction

- Help us learn more about your shopping preferences

- Conduct marketing and performance research to assist us in measuring our customer services, benchmarking our performance and to help us improve your shopping experiences and product offerings

- Send communication related to order updates and offers through e-mail, SMS and social media channels. This option will be auto renewed after 180 days and if you wish to unsubscribe from receiving offer updates, you can do so.

4. WITH WHOM WE SHARE THE PERSONAL AND SENSITIVE INFORMATION

Only the persons authorized by us shall have access to your Personal Information and Sensitive Information. We may share your Personal and Sensitive information with:

- Our affiliates

- Service providers who perform services on our behalf based on our instructions which inter alia include beauty partners providing beauty services to the customers. However, these service providers will not be authorized to use or disclose such information except as necessary to perform services on our behalf or comply with legal requirements

- Other third parties with your consent (e.g. Facebook applications may share information collected through those apps with your Facebook friends or other Facebook users)

We do not rent or sell your Personal and Sensitive Information to any third party. However, should we plan to merge/sell all or substantially all of our business to another business entity or similar other transaction or be required by that business entity, we may transfer or disclose your Personal Information and Sensitive Information to that business entity who may collect, use or disclose such information for the purposes of evaluating the proposed transaction or for operating and managing the affairs of the acquired business or for other purposes identified in this Policy.

Notwithstanding anything contained in this Privacy Policy, we reserve the right to disclose any Personal Information or Sensitive Information that may be required to be disclosed mandatorily under applicable law or where the disclosure is necessary to comply with any legal obligation or to law enforcement authorities or other government officials, without prior notice or consent of the site / app user.

5. COOKIES

We may track your preferences and activities on the Site. "Cookies" are small data files transferred to your computer's hard-drive by a website. They keep a record of your activities on the Site making your subsequent visits to the site more efficient. Cookies may store a variety of information, including, the number of times that you access a site, registration information and the number of times that you view a particular page or other item on the site. The use of cookies is a common practice adopted by most major sites to better serve their clients. Most browsers are designed to accept cookies, but they can be easily modified to block cookies.

By continuing the use of the Site, you are agreeing to our use of cookies. If you do not agree to our use of cookie, you can block them in your browser setting, but you may lose some functionality on the Site.

6. HOW WE RETAIN OF SENSITIVE PERSONAL DATA OR INFORMATION

We will retain your Personal and Sensitive Information only as long as it is reasonably required or otherwise permitted or required by applicable law or regulatory requirements. We may also retain your Personal and Sensitive Information so long as it is necessary to fulfil the purposes for which it was collected (including for purposes of meeting any legal, administrative, accounting, or other reporting requirements). Your Personal and Sensitive Information is safeguarded against inappropriate access and disclosure, as per this Privacy Policy.

We also maintain appropriate and adequate administrative, technical and physical safeguards designed to protect your Personal and Sensitive Information against accidental, unlawful or unauthorized destruction, loss, alteration, access, disclosure or use.

7. WITHDRAWAL OF CONSENT

If you have consented to the collection, use and/or disclosure of your Personal and Sensitive Information as identified in this Policy, you may withdraw the same at any time by communicating to us at the given below under Clause 11.

8. SECURITY

We endeavour to keep your Personal and Sensitive information secure, up-to-date, accurate in the best possible manner as it may be necessary for the purpose for which it was collected. We value the importance you attach to your Personal and Sensitive Information given to us and therefore we have (i) taken all reasonable measures and precautions to keep such information safe and secure and to prevent any unauthorized access to or misuse of the same; and (ii) enable you to review and edit the same.

However, we shall not be liable to any user for any loss, damage (whether direct, indirect, consequential or incidental) or harm caused to the user due to the unauthorized access or misuse of the Personal or Sensitive Information by any third party.

9. CONTACT INFORMATION

PrettyClick Customer Service

E-mail id:support@prettyclickcosmetics.com

Phone:+9771 4570725

Contact Days:

- Sunday to Friday (10:00 a.m. to 6:00 p.m.)

- Saturday (Closed)

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.