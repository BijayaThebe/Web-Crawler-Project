✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

52 products

## Filter

- In stock47

- Out of stock23

- Gold1

- Rose Gold1

- In stock47

- Out of stock23

- Gold1

- Rose Gold1

BB Cream

### L.A. Girl Pro Bb Cream

### Choose your option

Foundation

### L.A. Girl Pro Matte Foundation

### Choose your option

Foundation

### L.A. Girl Pro Coverage Illuminating Foundation

### Choose your option

Lipliner

### L.A. Girl Shockwave Nude Lip Liner Pencil

### Choose your option

Mascara

### L.A. Girl Volumatic Mascara

### Choose your option

Setting Powder

### L.A. Girl Pro face powder

### Choose your option

Highlighter

### L.A. Girl luminous glow highlighter

### Choose your option

Concealer

### L.A. Girl Pro Concealer

### Choose your option

Eyeliner

### L.A. Girl Pastel Dream Auto Liner

### Choose your option

Eyeshadow

### L.A. Girl Keep it Playful Eyeshadow

### Choose your option

Foundation

### L.A. Girl Pro Color Foundation Mixing Pigment

### Choose your option

Setting Spray

### L.A. Girl Shimmery Spray Finishing Spray For Face & Body

### Choose your option

Eyeliner

### L.A. Girl Shock Wave Metallic Eyeliner Pencil

### Choose your option

Brow Pomade

### L.A. Girl Brow Pomade

### Choose your option

primer

### L.A. Girl Pro Face Primer

### Choose your option

Blush

### L.A. Girl Rosy Glow Envy Bouncy Blush

### Choose your option

Eyeliner

### L.A. Girl Shockwave Eyeliner

### Choose your option

Setting Powder

### L.A. Girl Pro HD Setting Powder

### Choose your option

Eyeliner

### L.A. Girl Skinny Gel Eyeliner

### Choose your option

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick