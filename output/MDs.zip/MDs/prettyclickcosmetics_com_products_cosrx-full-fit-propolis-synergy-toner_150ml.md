✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

# Cosrx Full Fit Propolis Synergy Toner 150 ml

## Cosrx Full Fit Propolis Synergy Toner 150 ml

Vendor:Cosrx

Type:Toner

Earn 5% prettyclick reward points on every purchase

- 100% Authentic

Available in stock

Letter of Authentication

BENEFITS

• Nourish for healthy skin• Plump, glowing skin• Reduce redness• Improve skin texture

TARGETS

• Dull, dehydrated skin• Red, irritated skin* Great for all skin types and seasons

- Free Delivery for orders over Rs 3500

- Exchange within 7 days if the sealed is not opened

### Cosrx Full Fit Propolis Synergy Toner 150 ml

## Customer Reviews

I am using it since 6 months and its really nice.

Make my skin too much soft and glowingAnd it’s make my skin healthy and support my skin barrier too well

I really love using this product..Really hydrates my skin❤️

Its hydrating and makes a difference

Love this product , it makes the skin so dewy and soft.

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick