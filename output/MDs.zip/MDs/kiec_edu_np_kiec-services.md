- OSHC

- STUDENT ACCOMMODATION

- NEWS & OFFER

- COUNSELOR DASHBOARD

- LOGINSTUDENT LOGIN

- STUDENT LOGIN

# ServiceWe Provide

#### KIEC’s wide range of services encompass every stage, right from identification of universities till pre-departure orientation. This makes things easy and smooth for you, to effectively concentrate on your strengths and dreams – of studying in your Dreamland.

#### Pre-departure Orientation

#### Test Preparation

#### Student Accommodation

#### Education Counseling

#### Scholarship Guidance

#### University Admission

## MoreServices

- International Educational Loans

- Assistance in Filling of Applicants

- 100% Visa Assistance

- Providing International Student ID Card

- Assistance in Documentation for Admission

- Discounts on tickets and extra luggage

- Tie-up with student travel and Medical Insurance providers

- Regular follow-up with Universities/Colleges

- Coaching for IELTS, TOEFL-iBT, PTE-A, OET, SAT

## ComparativeStatement

#### KIEC

#### Other Compettors

Choosing the right course in right university/right country

Information on entry requirements

Comprehensive information about universities

Course curriculum and career prospects

Financial aid / scholarship assistance

Admission formalities

SOP / Essay guidelines

Recommendation Letters

Organizing on-spot assessment / spot admissions

Visa Guidance

Per departure orientation

Travel assistance / guidance

## Study abroadfrom

## Study abroadfrom

### 250k

### Congratulations

### Congratulations

### Post-Study Counseling

## Study abroadfrom

### 250k

### Congratulations

### Post-Study Counseling

## OurLocation

### Dang

### Butwal

### pokhara

### Chitwan

### Birjunj

### KTM

### Lalitpur

### Itahari

### Biratnagar

### Nepalgunj

### Hetauda

## OurLocation

### Dang

### Butwal

### pokhara

### Chitwan

### Birjunj

### KTM

### Lalitpur

### Itahari

### Biratnagar

### Birtamode

### Nepalgunj

### Hetauda