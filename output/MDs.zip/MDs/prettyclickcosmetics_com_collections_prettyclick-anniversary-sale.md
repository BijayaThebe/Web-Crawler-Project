✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

84 products

## Filter

- In stock60

- Out of stock34

- In stock60

- Out of stock34

Blush

### L.A. Colors Jelly Cool Tinted Blush Stick

### Choose your option

Beauty Blender

### Prettyclick Soft & High Resilience 5 Pcs Beauty Blender

### Choose your option

Mask

### Dear Klairs Freshly Juiced Vitamin E Mask 90g

### Choose your option

Serum

### Timeless Matrixyl®️ 3000+ Hyaluronic Acid Serum

### Choose your option

deodorant

### Degree 72H+ Ultra Clear Black + White Deodorant 6g -Fresh

### Choose your option

Accessories

### Cala Personal Trimmer For Men

### Choose your option

Conditioner

### Aussie Miracle Moist Conditioner 360ml

### Choose your option

Nail Tip

### L.A. Colors Chrome Mirror Finish Artificial Nails Tips-Stiletto

### Choose your option

Necklace

### J Babe Choker Necklace

### Choose your option

hair clips

### J Babe 3D Star Clips - Purple

### Choose your option

Conditioner

### Dermae Restoring Conditioner

### Choose your option

Skincare

### Roc Multi Correction Hydrate +Plump Eye Cream

### Choose your option

Accessories

### J Babe Hair Bow Clips - Pink

### Choose your option

Eyelash

### L.A. Colors All Is Bright 5 Pcs Pretty Wispy Eyelash Set

### Choose your option

Artificial nail

### L.A. Colors All Is Bright 28 Pcs Shine Artificial Nail Tips

### Choose your option

Acne Treatment

### Dermae Scar Gel

### Choose your option

Nail Tip

### La Colors Lavish Nail Tip Kit

### Choose your option

Sponge

### L.A. Colors 3 Pcs Precision Mini Sponge

### Choose your option

Eyeliner

### L.A. Colors All Is Bright 5 Pcs Defined Looks Automatic Eyeliner Set

### Choose your option

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick