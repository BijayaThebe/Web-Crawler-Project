- SERVICESRelaxation MassageSignature MassageTherapeutic MassageMini TherapyLadies Beauty ServicesGentlemen Salon ServicesVastiCuppingHydroTherapy

- PACKAGESBeauty PackageSpa PackageSeasonal Package

- MEMBERSHIPSolatee MembershipTranquility Wellness Card

- ABOUTWelcome To Tranquility SpaHistoryMission And VisionTeams

- OUTLETSThe Soaltee KathmanduHotel Radission KathmanduChandragiri Hills ResortHotel SarowarHotel Crown ImperialHotel ShankerTranquility Spa - JhamsikhelKupondole

- BLOGS

- CAREERS

- CONTACT

# OUR PACKAGES

##### Starting From Rs
                            16000-27000/-

##### Starting From Rs
                            44999/-

##### Starting From Rs
                            7500-9500/-

##### Starting From Rs
                            7000-9000/-

##### Starting From Rs
                            14,999/-

##### Starting From Rs
                            6999-9000/-

##### Starting From Rs
                            14999/-

##### Starting From Rs
                            8999-11999/-

##### Starting From Rs
                            27000/-

#### Our Associated Partners