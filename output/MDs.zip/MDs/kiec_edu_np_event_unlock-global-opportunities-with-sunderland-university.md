- OSHC

- STUDENT ACCOMMODATION

- NEWS & OFFER

- COUNSELOR DASHBOARD

- LOGINSTUDENT LOGIN

- STUDENT LOGIN

## Unlock Global Opportunities with Sunderland University!

## EventDetails

### 12th September 2025, Friday

### KIEC Avenue, Lalupatey marga, Putalisadak

Step Into Your UK Study Adventure!✨

Curious about studying at a top UK university? Want an insider’s look at student life at the University of Sunderland?

Don’t miss this exclusive session with David Pepper, the official representative of the University of Sunderland. Get your questions answered and receive personalized guidance for your study abroad journey!

Why choose the University of Sunderland?🌟 World-class programs: High-quality courses across a wide range of fields.💼 Strong industry connections: Opportunities for internships and real-world experience.🎓 Vibrant campus life: Diverse student community with modern facilities.🌏 Global recognition: Internationally accredited degrees that open doors worldwide.

𝐅𝐨𝐫 𝐦𝐨𝐫𝐞 𝐝𝐞𝐭𝐚𝐢𝐥𝐬, 𝐯𝐢𝐬𝐢𝐭 𝐮𝐬 𝐚𝐭:KIEC Avenue44-05, Lalupatey Marg, Putalisadak, KTM, Nepal📞 +977 4531221, 01 4516197📍 https://bit.ly/KIEC_Avenue📩[email protected]

If you cannot attend this session, please visit nearest KIEC offices

𝐅𝐨𝐫 𝐛𝐫𝐚𝐧𝐜𝐡𝐞𝐬, 𝐲𝐨𝐮 𝐜𝐚𝐧 𝐯𝐢𝐬𝐢𝐭:🌐 www.kiec.edu.np/contact-us

Your direct connection to the University of Sunderland awaits—make sure you’re part of it!

# StudyAbroad #UKUniversities #SunderlandUniversity #KathmanduEvents #EducationConsulting #FutureIsBright #KIECNepal