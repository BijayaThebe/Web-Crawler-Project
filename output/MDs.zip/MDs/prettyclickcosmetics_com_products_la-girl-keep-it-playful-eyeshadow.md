✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

# L.A. Girl Keep it Playful Eyeshadow

## L.A. Girl Keep it Playful Eyeshadow

Vendor:La Girl

Type:Eyeshadow

Earn 5% prettyclick reward points on every purchase

- 100% Authentic

Available in stock

Are you DTP (down to play)? Keep it Playful is always down for you. These 9 pan eyeshadow palettes are like a cute mini version of our full-sized, best-selling palettes. But when it comes to pigment... these shadows aren't playing with payoff. Trust, when you swatch these soft mattes, smooth shimmers, and intense foils they will blow your mind. Each palette is its own experience with their color coordinating shades in fiery warm tones, sultry smoky shades, blushing rose colors, and flirtatious purple eyeshadows. You can dress it up, or dress it down, as long as you Keep it Playful.

- Soft Mattes, Smooth Shimmers & Intense Foils

- 9 Playful Colors

- Easy to Blend Eyeshadows

- Travel Friendly, Compact Eyeshadow Palette

- Color-Coordinated Metallic Packaging

- Magnetic Case

- Free Delivery for orders over Rs 3500

- Exchange within 7 days if the sealed is not opened

### L.A. Girl Keep it Playful Eyeshadow

## Customer Reviews

La Girl Keep it Playful Eyeshadow

Im impressed by all the Product which prettyclick provides.some products are pricey but it should last awhile and if it gives good results, it's worth it. Im eager to try other products in this line.

its the perfect eyeshadow for daily use and for night glam too. such a pigmented colors and less fall out.

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick