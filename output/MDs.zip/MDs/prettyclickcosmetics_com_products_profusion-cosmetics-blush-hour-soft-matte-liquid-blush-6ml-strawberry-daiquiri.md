✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

# Profusion Cosmetics Blush Hour Soft Matte Liquid Blush 6ml- Strawberry Daiquiri

## Profusion Cosmetics Blush Hour Soft Matte Liquid Blush 6ml- Strawberry Daiquiri

Vendor:Profusion Cosmetics

Type:Blush

Earn 5% prettyclick reward points on every purchase

- 100% Authentic

Available in stock

It's Blush Hour, and we're mixing up something special just for you! Our Liquid Blush is like a cocktail-inspired fusion for your cheeks - with a twist! This neat formula goes on smooth and dries to a soft matte finish, giving you a richly pigmented flush that is vegan and cruelty-free, making it a guilt-free indulgence. With shades like Mai Tai, Cosmo, and Blushing Margarita, you can garnish your cheeks with a pop of color that will last from brunch to a night out on the town. Let's raise a glass to the perfect flushed-from-within glow.

HIGHLIGHTS:

The Perfect Blend:Blush Hour is a unique mixture of a cream to soft matte finish that will give your cheeks a richly pigmented pop of color. Customize your look from a subtle flush to a more intense glow.

Cheers To Long-Lasting Wear: With a twist of the applicator, this innovative formula is designed to blend the product for a seamless finish that will last all day.

Cocktail-Inspired Hues:With a range of 10 cocktail-inspired hues to choose from, Blush Hour offers the perfect blend of colors for every skin tone.

• Strawberry Daquiri – Coral Pink

- Free Delivery for orders over Rs 3500

- Exchange within 7 days if the sealed is not opened

### Profusion Cosmetics Blush Hour Soft Matte Liquid Blush 6ml- Strawberry Daiquiri

## Customer Reviews

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick