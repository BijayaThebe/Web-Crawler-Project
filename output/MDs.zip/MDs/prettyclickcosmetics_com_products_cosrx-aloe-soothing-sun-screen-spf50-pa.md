✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

# Cosrx Aloe Soothing Sun Cream SPF50+ PA+++

## Cosrx Aloe Soothing Sun Cream SPF50+ PA+++

Vendor:Cosrx

Type:Sunscreen

Earn 5% prettyclick reward points on every purchase

- 100% Authentic

Available in stock

Letter of Authentication

BENEFITS

• Block UV rays• Soothes & moisturizes skin• Lightweight texture

TARGETS

• Doesn't want a white cast• Enjoy outdoor activities often• Dehydrated skin

- Free Delivery for orders over Rs 3500

- Exchange within 7 days if the sealed is not opened

### Cosrx Aloe Soothing Sun Cream SPF50+ PA+++

## Customer Reviews

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick