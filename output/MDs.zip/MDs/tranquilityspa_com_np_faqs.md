- SERVICESRelaxation MassageSignature MassageTherapeutic MassageMini TherapyLadies Beauty ServicesGentlemen Salon ServicesVastiCuppingHydroTherapy

- PACKAGESBeauty PackageSpa PackageSeasonal Package

- MEMBERSHIPSolatee MembershipTranquility Wellness Card

- ABOUTWelcome To Tranquility SpaHistoryMission And VisionTeams

- OUTLETSThe Soaltee KathmanduHotel Radission KathmanduChandragiri Hills ResortHotel SarowarHotel Crown ImperialHotel ShankerTranquility Spa - JhamsikhelKupondole

- BLOGS

- CAREERS

- CONTACT

## Looking for answers?

## What services does Tranquility Spa offer?

We provide a wide range of services including massages (Swedish, deep tissue, hot stone), facials, body wraps, manicures, pedicures, and waxing. Specialized packages for couples and groups are also available.

## Where are your spa locations in Nepal?

Tranquility Spa has multiple branches across Nepal, including Kathmandu, Pokhara, Chitwan, and other popular destinations. A full list of our locations is available on our website.

## What are your opening hours?

Most of our spas are open daily from 7:00 AM to 9:00 PM, though timings may vary slightly by location.

## What are your treatment prices?

Prices vary depending on the service and location. Please check our spa menu or contact your nearest branch.

## Do I need to make a reservation, or do you accept walk-ins?

We highly recommend booking in advance to secure your preferred time and therapist, especially on weekends and holidays. Walk-ins are welcome based on availability.

## What is your cancellation policy?

We require at least 24 hours’ notice for cancellations or rescheduling. Late cancellations (within 24 hours) may incur a 50% charge, while no-shows will be charged the full service fee.

## How do I book an appointment?

You can book via our website’s online booking system, call us directly at your chosen outlet, or visit our reception desk during operating hours.

## What if I am late for my appointment?

We will try to accommodate you, but your session may be shortened to respect other bookings.

## What should I expect during my first visit?

Our team will guide you through the process, help you choose the right treatment, and ensure a comfortable, relaxing experience.

## What should I do to prepare for my spa appointment?

Arrive at least 15 minutes early to check in, change, and relax. Please inform us of any health conditions, allergies, or medications. For facials, avoid heavy makeup; for waxing, ensure hair is at least 1/4 inch long.

## What should I wear to the spa?

Comfortable clothing is recommended. We provide robes, slippers, and disposable undergarments during your treatment.

## Do you have facilities like lockers, showers, or a relaxation area?

Yes, we provide private lockers, showers, and a serene relaxation lounge. Complimentary robes and slippers are included with your visit.

## Do you allow photography inside the spa?

To maintain guest privacy, photography is not permitted in treatment areas.

## What if I have a specific health concern ?

Please let us know when booking. Our therapists are trained to adapt treatments for your safety and comfort. Some services may not be recommended in certain situations.

## Are there any age restrictions for services?

Guests must be at least 16 years old to receive services independently. Minors aged 12–15 may receive select treatments with a parent/guardian present and providing consent.

## What payment methods do you accept?

&nbsp;We accept major credit cards (Visa, MasterCard, American Express, Discover), debit cards, cash, and Tranquility Spa gift certificates.

## Do you offer gift certificates?

Yes. They can be purchased online, over the phone, or in person for a specific service or a monetary value.

#### Our Associated Partners