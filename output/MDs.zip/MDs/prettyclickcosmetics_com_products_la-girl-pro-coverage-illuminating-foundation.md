✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

# L.A. Girl Pro Coverage Illuminating Foundation

## L.A. Girl Pro Coverage Illuminating Foundation

Vendor:La Girl

Type:Foundation

Earn 5% prettyclick reward points on every purchase

- 100% Authentic

Available in stock

Seamless, full-coverage, skin-like finish so flawless, they’ll be asking who did your makeup. PRO.coverage HD Illuminating Foundation has a buildable, lightweight, antioxidant rich formula that hydrates and helps improve skin appearance while you wear. Cover imperfections, and even out skin tone with a dewy, radiant finish that looks like your skin, but better. It’s like having a pro MUA in a bottle.

PRO Tip: Try the white foundation mixer to lighten your summer shade for winter or use as a white base for creative makeup looks.

- Buildable, medium-to-full coverage foundation

- Dewy, radiant finish

- Formulated with vitamin E & vitamin C

- Hydrates and improves skin appearance

- Cruelty-free, paraben-free & vegan

- Free Delivery for orders over Rs 3500

- Exchange within 7 days if the sealed is not opened

### L.A. Girl Pro Coverage Illuminating Foundation

## Customer Reviews

Loved it

Nice

I have been using the foundation for past 1 year. I have been very happy with the quality of the product it blends really well and provides full coverage. It has been my go to foundation. I have recommended the same to many of my friends as well.

My most used foundation product. Perfect for dry skin and those who want natural finish look. And also best product for winter dewy look.

I loved it

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick