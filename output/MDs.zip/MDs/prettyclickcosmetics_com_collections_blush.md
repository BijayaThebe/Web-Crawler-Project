✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

25 products

## Filter

- In stock18

- Out of stock11

- In stock18

- Out of stock11

Blush

### L.A. Colors Blush Up Cheek & Lip Cream

### Choose your option

Blush

### L.A. Girl Soft Matte Cream Blush

### Choose your option

Blush

### Milani Baked Blush

### Choose your option

Blush

### Milani Cheek Kiss Cream Blush

### Choose your option

Blush

### Milani Rose Cheek Kiss Liquid Blush

### Choose your option

Blush

### L.A. Colors Jelly Cool Tinted Blush Stick

### Choose your option

Blush

### Beauty Creations Stay Blushin' Cute Lip and Cheek Balm

### Choose your option

Blush

### L.A. Girl Rosy Glow Envy Bouncy Blush

### Choose your option

Blush

### J. Cat Beauty Blush Mallow Soft Blusher

### Choose your option

Blush

### The Balm Third Date Blush

### Choose your option

Blush

### The Balm It's a Date Blush

### Choose your option

Blush

### The Balm Big Date Blush

### Choose your option

Blush

### The Balm Hot Mama! Shadow/Blush

### Choose your option

Blush

### Beauty Creations Matte Blush Hush

### Choose your option

Blush

### The Balm Double Crosser Highlighter, Bronzer & Blush

### Choose your option

Blush

### Profusion Cosmetics Blush Hour Soft Matte Liquid Blush 6ml- Strawberry Daiquiri

### Choose your option

Blush

### Milani Cheek Kiss Blush + Glow Liquid Blush 10ml

### Choose your option

Blush

### Profusion Cosmetics Blush Hour Soft Matte Liquid Blush 6ml- Aperol Spritz

### Choose your option

Blush

### Beauty Creations Rosy McMichael Pink Dream Blushes

### Choose your option

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick