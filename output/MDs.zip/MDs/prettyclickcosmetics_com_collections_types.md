✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

14 products

## Filter

- In stock5

- Out of stock9

- In stock5

- Out of stock9

Body Mist

### SO...? Hawaiian Honey Body Mist 200ml

### Choose your option

Body Mist

### SO...? Seychelle Sands Body Mist 200ml

### Choose your option

Body Mist

### SO…? Barcelona Babe Body Mist 200ml

### Choose your option

Body Mist

### SO…? Cali Night Body Mist 200ml

### Choose your option

Body Mist

### SO…? Caribbean Soul Body Mist 200ml

### Choose your option

Body Mist

### SO…? Majorca Love Body Mist 200ml

### Choose your option

Body Mist

### SO…? Musk Body Mist 100ml

### Choose your option

Body Mist

### SO…? Mykonos Nights Body Mist 200ml

### Choose your option

Body Mist

### SO…? Peony Petals Body Mist 100ml

### Choose your option

Body Mist

### SO…? Pink Lemonade Body Mist 100ml

### Choose your option

Body Mist

### SO…? Rainbow Sorbet Body Mist 100ml

### Choose your option

Body Mist

### SO…? Sweet Floral Body Mist 100ml

### Choose your option

Body Mist

### SO…? Sweet Pea Body Mist 100ml

### Choose your option

Body Mist

### SO…? Watermelon Body Mist 100ml

### Choose your option

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick