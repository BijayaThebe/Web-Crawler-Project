✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

17 products

## Filter

- In stock11

- Out of stock7

- In stock11

- Out of stock7

Mascara

### L.A. Colors Biggie Lash Mascara

### Choose your option

Mascara

### L.A. Colors Dramatilash Volume Mascara-Black

### Choose your option

Mascara

### L.A. Girl Volumatic Mascara

### Choose your option

Mascara

### La Colors X - volume Mascara Extreme Black

### Choose your option

Mascara

### Maybelline Lash Sensational Mascara -Midnight Black

### Choose your option

Mascara

### Maybelline Lash Sensational Sky High Waterproof Mascara -Very Black

### Choose your option

Mascara

### Milani Highly Rated Anti Gravity Mascara - 115

### Choose your option

Mascara

### Milani Highly Rated Anti Gravity Waterproof Mascara -120

### Choose your option

Mascara

### Milani Highly Rated Instant Volume & Curl Mascara - 111

### Choose your option

Mascara

### Milani Highly Rated Lash Extensions Mascara

### Choose your option

Mascara

### Milani Highly Rated Waterproof Mascara

### Choose your option

Mascara

### Wet n Wild Big Poppa Mascara 10ml

### Choose your option

Mascara

### Wet n Wild Breakup Proof Waterproof Boosting Mascara

### Choose your option

Mascara

### Wet n Wild Max Volume Plus Mascara

### Choose your option

Mascara

### Wet n Wild Mega Protein Waterproof Mascara

### Choose your option

Mascara

### Wet n Wild Mega Volume Mascara 10ml

### Choose your option

Mascara

### Wet n Wild So Defined Volumizing + Defining Mascara

### Choose your option

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick