- OSHC

- STUDENT ACCOMMODATION

- NEWS & OFFER

- COUNSELOR DASHBOARD

- LOGINSTUDENT LOGIN

- STUDENT LOGIN

# Home forGlobal Students

## Home forGlobal Students

### Right Place, Right Price

### End to End Support

### Roommate Search

## Australian Homestay Network

The Australian Homestay Network (AHN) is Australia’s largest and most recognised homestay provider, ensuring that each guests begins their Australian experience on the right foot. They believes that a homestay program should provide international students with much more than a place to sleep and eat.

## Amber Student

## Uhomes

## UniAcco

UniAcco is a cross-border prop-tech student accommodation platform that provides students with premium student housing located close to their universities and colleges. UniAcco has become a trusted name in the field of premium student housing..

## Study abroadfrom

## Study abroadfrom

### 250k

### Congratulations

### Congratulations

### Post-Study Counseling

## Study abroadfrom

### 250k

### Congratulations

### Post-Study Counseling

## OurLocation

### Dang

### Butwal

### pokhara

### Chitwan

### Birjunj

### KTM

### Lalitpur

### Itahari

### Biratnagar

### Nepalgunj

### Hetauda

## OurLocation

### Dang

### Butwal

### pokhara

### Chitwan

### Birjunj

### KTM

### Lalitpur

### Itahari

### Biratnagar

### Birtamode

### Nepalgunj

### Hetauda