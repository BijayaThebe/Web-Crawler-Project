✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

## Upto 30% OFF ON COSRX

Sunscreen

### Cosrx Aloe Soothing Sun Cream SPF50+ PA+++

### Choose your option

serum

### Cosrx The Niacinamide 15 Serum

### Choose your option

Power Essence

### Cosrx Advanced Snail 96 Mucin Power Essence

### Choose your option

Cleanser

### Cosrx Low pH Good Morning Gel Cleanser 150ml

### Choose your option

Eye Cream

### Cosrx Advanced Snail Peptide Eye Cream

### Choose your option

Toner

### Cosrx Full Fit Propolis Synergy Toner 150 ml

### Choose your option

## 25% off on La Girl

BB Cream

### L.A. Girl Pro Bb Cream

### Choose your option

Foundation

### L.A. Girl Pro Matte Foundation

### Choose your option

Foundation

### L.A. Girl Pro Coverage Illuminating Foundation

### Choose your option

Lipliner

### L.A. Girl Shockwave Nude Lip Liner Pencil

### Choose your option

Mascara

### L.A. Girl Volumatic Mascara

### Choose your option

Setting Powder

### L.A. Girl Pro face powder

### Choose your option

## 20% OFF

Toner

### I'm From Black Rice Toner 150ml

### Choose your option

Toner

### I'm From Black Rice Toner 30ml

### Choose your option

Cream

### I'm From Rice Cream 50g

### Choose your option

Face mask

### I'm From Rice Mask 110g

### Choose your option

Serum

### I'm From Rice Serum 30ml

### Choose your option

Toner

### I'm From Rice Toner 150ml

### Choose your option

## SPECIAL DASHAIN OFFER

Palette

### Wet n Wild Megaglo Contour Palette - Dulce De Leche

### Choose your option

Brow Gel

### Wet n Wild Mega Stay Extreme Hold Brow Gel 5.6ml

### Choose your option

Highlighter

### Wet n Wild Megaglo Vitamin E Makeup Highlight Stick 6 g

### Choose your option

primer

### Wet n Wild Prime Focus Primer Serum 30ml

### Choose your option

Lip Liner

### Wet n Wild Perfect Pout Lip Liner Stain 0.5ml

### Choose your option

Foundation

### Wet n Wild Photo Focus Matte Foundation

### Choose your option

ON ALL PRETTYCLICK LIP COLLECTION

Offer Ends 1st October

Be a Part of Amazing Prettyclick Loyalty Reward program  - Coming Soon

## 10% OFF ON KUNDAL

#1 SHAMPOO OF KOREA

## Prettyclick Lipstick

Lipstick

### Prettyclick Bullet Lipstick 3g: Beloved

### Choose your option

Lipstick

### Prettyclick Bullet Lipstick 3g: Stunner

### Choose your option

Lipstick

### Prettyclick Bullet Lipstick 3g: Ruby Flame

### Choose your option

Lipstick

### Prettyclick Bullet Lipstick 3g: Dream Girl

### Choose your option

Lipstick

### Prettyclick Bullet Lipstick 3g: City Girl

### Choose your option

DASHAIN AYO OFFER LYAYO

Blush

### L.A. Colors Jelly Cool Tinted Blush Stick

### Choose your option

Beauty Blender

### Prettyclick Soft & High Resilience 5 Pcs Beauty Blender

### Choose your option

Mask

### Dear Klairs Freshly Juiced Vitamin E Mask 90g

### Choose your option

Serum

### Timeless Matrixyl®️ 3000+ Hyaluronic Acid Serum

### Choose your option

deodorant

### Degree 72H+ Ultra Clear Black + White Deodorant 6g -Fresh

### Choose your option

Accessories

### Cala Personal Trimmer For Men

### Choose your option

## Shop By  Popular Categories

### Foundation

### Concealer

### Setting Spray

### Liquid Lipstick

### Sunscreen

### Nails

## New Launch

Due to the overwhelming success of our Prettyclick Lip Cream, we’re excited to introduce 4 new stunning shades. Check them out now!

## Prettyclick lip Cream

Lip Cream

### Prettyclick Lip Cream - Desire

### Choose your option

Lip Cream

### Prettyclick Lip Cream - Mocha

### Choose your option

Lip Cream

### Prettyclick Lip Cream - Petal

### Choose your option

Lip Cream

### Prettyclick Lip Cream - Charming

### Choose your option

Lip Cream

### Prettyclick Lip Cream- Love

### Choose your option

Lip Cream

### Prettyclick Lip Cream - Passion

### Choose your option

Lip Cream

### Prettyclick Lip Cream- Hope

### Choose your option

## Makeup

Setting Spray

### Milani 16HR Make It Dewy Setting Spray

### Choose your option

Foundation

### Milani Conceal + Perfect 2 In One Foundation + Concealer

### Choose your option

Mascara

### Milani Highly Rated Anti Gravity Mascara - 115

### Choose your option

primer

### Milani Conceal + Perfect Blur Out Smoothing Primer 21g

### Choose your option

Powder

### Milani Conceal+Perfect Shine-Proof Powder

### Choose your option

Eyeliner

### Milani Stay Put Matte 17HR Wear Liquid Eyeliner Waterproof - 150

### Choose your option

## Biggest Offer of the year for Body Mist

Body Mist

### SO…? Sweet Pea Body Mist 100ml

### Choose your option

Body Mist

### SO…? Sweet Floral Body Mist 100ml

### Choose your option

Body Mist

### SO…? Musk Body Mist 100ml

### Choose your option

Body Mist

### SO…? Peony Petals Body Mist 100ml

### Choose your option

Body Mist

### SO…? Barcelona Babe Body Mist 200ml

### Choose your option

Body Mist

### SO…? Rainbow Sorbet Body Mist 100ml

### Choose your option

## Customer's Choice

Sunscreen

### Cosrx Aloe Soothing Sun Cream SPF50+ PA+++

### Choose your option

serum

### Cosrx The Niacinamide 15 Serum

### Choose your option

Power Essence

### Cosrx Advanced Snail 96 Mucin Power Essence

### Choose your option

Cleanser

### Cosrx Low pH Good Morning Gel Cleanser 150ml

### Choose your option

Eye Cream

### Cosrx Advanced Snail Peptide Eye Cream

### Choose your option

Toner

### Cosrx Full Fit Propolis Synergy Toner 150 ml

### Choose your option

## GOOD FOR YOUR SKIN

## Trending Now

Blush

### Profusion Cosmetics Blush Hour Soft Matte Liquid Blush 6ml- Strawberry Daiquiri

### Choose your option

Highlighter

### Profusion Cosmetics Radiant Glow Illuminating Liquid Highlighter 14.5ml- Rose Quartz

### Choose your option

Foundation

### Profusion Cosmetics Feel Good Skin Long Wear Skin Perfector 30ml- Fair 1

### Choose your option

Foundation

### Profusion Cosmetics Feel Good Skin Long Wear Skin Perfector 30ml- Medium 5

### Choose your option

Blush

### Profusion Cosmetics Blush Hour Soft Matte Liquid Blush 6ml- Aperol Spritz

### Choose your option

Highlighter

### Profusion Cosmetics Radiant Glow Illuminating Liquid Highlighter 14.5ml- Champagne

### Choose your option

### Accessories

### Eyeshadow

### Face Mask

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick