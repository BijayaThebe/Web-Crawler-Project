- OSHC

- STUDENT ACCOMMODATION

- NEWS & OFFER

- COUNSELOR DASHBOARD

- LOGINSTUDENT LOGIN

- STUDENT LOGIN

# journey :avisual tour

#### Top Scorer – British Council IELTS Mock Test | KIEC Nepal

#### Glimpse of Multi-Destination Education Fair 2025

#### Glimpse of Multi-Destination Education Fair 2025 Visitors

#### Glimpse Of Multi-Destination Education Fair 2025 Representatives

#### Dashain Masti 2024

#### KIEC Roadshow 2025 |  11 Cities, One Mission: Your Success!

#### Baglung Road Show 2025

#### Nepalgunj Road Show 2025

#### Birtamode Road Show 2025

#### Butwal Road Show 2025

#### Itahari Road Show 2025

#### Biratnagar Road Show 2025