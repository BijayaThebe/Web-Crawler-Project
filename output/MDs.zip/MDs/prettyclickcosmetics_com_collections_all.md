✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

857 products

## Filter

- In stock632

- Out of stock299

- Gold1

- Rose Gold1

- In stock632

- Out of stock299

- Gold1

- Rose Gold1

Setting Powder

### Airspun Loose Face Powder

### Choose your option

Makeup Brush

### Alix Avien Paris Contour Brush

### Choose your option

Makeup Brush

### Alix Avien Paris Foundation Brush

### Choose your option

Cream

### Anua Heartleaf 70% Intense Calming Cream - 50 ml

### Choose your option

Toner

### Anua Heartleaf 77% Soothing Toner - 250 ml

### Choose your option

Skincare > Cleansing Oil

### Anua Heartleaf Pore Control Cleansing Oil - 200 ml

### Choose your option

Facial Cleanser

### Anua Heartleaf Quercetinol Pore Deep Cleansing Foam - 150 ml

### Choose your option

Serum

### Anua Niacinamide 10% + Txa 4% Serum - 30 ml

### Choose your option

Serum

### Anua Peach 70% Niacinamide Serum - 30 ml

### Choose your option

Toner

### Anua Rice 70 Glow Milky Toner 250ml

### Choose your option

Eyelash

### Ardell Professional 1 Pair Faux Mink Demi Wispies

### Choose your option

Eyelash

### Ardell Professional 2 Pair Deluxe Pack

### Choose your option

Lashes

### Ardell Professional 4 Pair Faux Mink Demi Wispies

### Choose your option

Eyelash Glue

### Ardell Professional Lash Grip Clear Adhesive

### Choose your option

Eyelash

### Ardell Professional Magnetic Naked Lashes

### Choose your option

Eyelash

### Ardell Studio Effects Lashes Demi Wispies 1 pair

### Choose your option

Eyelash

### Ardell Studio Effects Lashes Wispies 1 pair

### Choose your option

Conditioner

### Aussie Miracle Moist Conditioner 360ml

### Choose your option

Shampoo

### Aussie Miracle Moist Shampoo 360ml

### Choose your option

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick