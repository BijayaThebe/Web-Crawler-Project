- OSHC

- STUDENT ACCOMMODATION

- NEWS & OFFER

- COUNSELOR DASHBOARD

- LOGINSTUDENT LOGIN

- STUDENT LOGIN

## Unlock Global Opportunities with Charles Darwin University

## EventDetails

### 23rd September 2025, Tuesday

### KIEC Avenue 44-05, Lalupatey Marg, Putalisadak, KTM, Nepal

🌏✨ Meet the Representatives from Charles Darwin University, Australia!

KIEC is excited to host Mr. Girish Iyer, Associate Vice Chancellor for South Asia, and Mr. Nikesh Vedi, Regional Marketing Manager, from Charles Darwin University. 🎓

📅 Date: 23rd September 2025 (Tuesday)🕐 Time: 12:45 PM – 1:45 PM📍 Venue: KIEC Avenue, Putalisadak, Kathmandu

This is a golden opportunity to:✅ Learn about study opportunities at CDU✅ Explore programs, scholarships & career pathways✅ Get expert guidance directly from university representatives

𝐅𝐨𝐫 𝐦𝐨𝐫𝐞 𝐝𝐞𝐭𝐚𝐢𝐥𝐬, 𝐯𝐢𝐬𝐢𝐭 𝐮𝐬 𝐚𝐭:KIEC Avenue44-05, Lalupatey Marg, Putalisadak, KTM, Nepal📞 +977 4531221, 01 4516197📍 https://bit.ly/KIEC_Avenue📩[email protected]

If you cannot attend this session, please visit nearest KIEC offices

𝐅𝐨𝐫 𝐛𝐫𝐚𝐧𝐜𝐡𝐞𝐬, 𝐲𝐨𝐮 𝐜𝐚𝐧 𝐯𝐢𝐬𝐢𝐭:🌐 www.kiec.edu.np/contact-us

Don’t miss your chance to interact and clear your doubts about studying in Australia! ✈️📚

# KIEC #CharlesDarwinUniversity #StudyInAustralia #MeetTheRepresentatives #FutureStartsHere