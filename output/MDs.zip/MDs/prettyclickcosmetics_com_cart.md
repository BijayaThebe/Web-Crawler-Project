✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

# Your cart(0)

## Your cart is currently empty.

Not sure where to start? Try these collections:

### Milani

### La Girl

### Wet and Wild

### Cosrx

### Skin1004

### La Colors

### Roc Skincare

### Good Molecules

## Recently viewed products

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick