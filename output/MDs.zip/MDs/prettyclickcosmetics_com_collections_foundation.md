✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

18 products

## Filter

- In stock17

- Out of stock6

- In stock17

- Out of stock6

Foundation

### L.A. Colors Truly Matte Long Wearing Foundation

### Choose your option

Foundation

### L.A. Colors Radiant Foundation

### Choose your option

Foundation

### L.A. Girl Pro Matte Foundation

### Choose your option

Foundation

### Milani Conceal + Perfect 2 In One Foundation + Concealer

### Choose your option

Foundation

### L.A. Girl Pro Coverage Illuminating Foundation

### Choose your option

Foundation

### L.A. Girl Pro Color Foundation Mixing Pigment

### Choose your option

Foundation

### Wet n Wild Photo Focus Dewy Foundation

### Choose your option

Foundation

### Wet n Wild Photo Focus Matte Foundation

### Choose your option

Foundation

### Profusion Cosmetics Feel Good Skin Long Wear Skin Perfector 30ml- Fair 1

### Choose your option

Foundation

### Profusion Cosmetics Feel Good Skin Long Wear Skin Perfector 30ml- Medium 5

### Choose your option

Foundation

### Profusion Cosmetics Feel Good Skin Long Wear Skin Perfector 30ml- Tan 3

### Choose your option

Foundation

### Profusion Cosmetics Feel Good Skin Long Wear Skin Perfector 30ml- Light 3

### Choose your option

Foundation

### Profusion Cosmetics Feel Good Skin Long Wear Skin Perfector 30ml- Medium 1

### Choose your option

Foundation

### Beauty Creations Flawless Stay Foundation

### Choose your option

Foundation

### Profusion Cosmetics Feel Good Skin Long Wear Skin Perfector 30ml- Light 200

### Choose your option

Foundation

### Profusion Cosmetics Feel Good Skin Long Wear Skin Perfector 30ml- Fair 100

### Choose your option

Foundation

### Profusion Cosmetics Feel Good Skin Long Wear Skin Perfector 30ml- Medium 320

### Choose your option

Foundation

### Profusion Cosmetics Feel Good Skin Long Wear Skin Perfector 30ml- Medium 300

### Choose your option

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick