✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

# Wet n Wild Perfect Pout Lip Liner Stain 0.5ml

## Wet n Wild Perfect Pout Lip Liner Stain 0.5ml

Vendor:Wet n wild

Type:Lip Liner

Earn 5% prettyclick reward points on every purchase

- 100% Authentic

Low stock

## About this item

- LONG-LASTING STAIN: Achieve a natural, just-bitten look with this lip liner stain that delivers a vibrant colour that lasts throughout the day

- PRECISION APPLICATOR: The blade-like applicator allows for effortless lining and defining of your lips, with a pointed tip for precise application and a flat side for easy filling

- TRANSFER-PROOF FORMULA: Enjoy all-day wear with a transfer-proof formula that keeps your lip colour intact, no matter the occasion

- LIP COMBO ESSENTIAL: Easily create a fuller, more defined lip look, this versatile lip liner stain is a must-have in your makeup collection for a flawless lip combo

- STAY WILD: We are the trusted beauty destination for beauty lovers of all ages, ethnicities, skin colours, and economic statuses; No matter who or where you are in life, we have a product for you!

- Free Delivery for orders over Rs 3500

- Exchange within 7 days if the sealed is not opened

### Wet n Wild Perfect Pout Lip Liner Stain 0.5ml

## Customer Reviews

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick