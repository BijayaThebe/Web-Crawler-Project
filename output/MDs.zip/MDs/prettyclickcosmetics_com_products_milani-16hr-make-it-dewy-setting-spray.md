✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

# Milani 16HR Make It Dewy Setting Spray

## Milani 16HR Make It Dewy Setting Spray

Vendor:Milani

Type:Setting Spray

Earn 5% prettyclick reward points on every purchase

- 100% Authentic

Available in stock

Don't let your statement slip ... set it! Our Make it Last setting sprays always keep your makeup looks striking, and this Dewy 3-in-1 Setting Spray Hydrate + Illuminate Set is equal parts moisturizer and time-stopper. Did someone say makeup with the moistness? Prime, set and hydrate your skin for the ultimate boost in brightness. Our Make it Dewy Setting Spray delivers a glamorous dose of dewy hydration to your complexion, for a fresh cooling feel. This hydrating setting spray locks in your makeup for up to 16 hours of wear. No need to worry about creasing, smudging or fading -- this setting spray locks in your look with dewiness, but not dampness. Spray it under or over your makeup, or wear on its own to make your skin really stand out. Keep it in your makeup bag for the perfect glow on the go!

- Free Delivery for orders over Rs 3500

- Exchange within 7 days if the sealed is not opened

### Milani 16HR Make It Dewy Setting Spray

## Customer Reviews

Perfect

I’m really in love with this spray since it provides that glowy base …. I always use it after applying primer and before foundation… make my skin glow and shine ✨

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick