- SERVICESRelaxation MassageSignature MassageTherapeutic MassageMini TherapyLadies Beauty ServicesGentlemen Salon ServicesVastiCuppingHydroTherapy

- PACKAGESBeauty PackageSpa PackageSeasonal Package

- MEMBERSHIPSolatee MembershipTranquility Wellness Card

- ABOUTWelcome To Tranquility SpaHistoryMission And VisionTeams

- OUTLETSThe Soaltee KathmanduHotel Radission KathmanduChandragiri Hills ResortHotel SarowarHotel Crown ImperialHotel ShankerTranquility Spa - JhamsikhelKupondole

- BLOGS

- CAREERS

- CONTACT

# OUR MEMBERSHIPS

### Tranquility Wellness Card

30% off on all services

### Solatee Membership

50% off in Massage Therapy

## Bronze
                            Membership

## Bronze Membership

### Benefits

### Terms

### Discounts & Offers

### Validity

#### Our Associated Partners