✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

30 products

## Filter

- In stock25

- Out of stock15

- In stock25

- Out of stock15

Eyeliner

### L.A. Colors Gel Eye Liner

### Choose your option

Eyeliner

### L.A. Colors Neon Gel Eye Liner

### Choose your option

Eyeliner

### L.A. Colors Matte Liquid Eyeliner

### Choose your option

Eyeliner

### L.A. Colors Chrome Liquid Eyeliner

### Choose your option

Eyeliner

### Milani Stay Put Matte 17HR Wear Liquid Eyeliner Waterproof - 150

### Choose your option

Eyeliner

### L.A. Colors Mark & Line Felt Tip Eyeliner

### Choose your option

Eyeliner

### L.A. Colors Holographic Liquid Eyeliner

### Choose your option

Eyeliner

### The Balm Schwing Liquid Eyeliner

### Choose your option

Eyeliner

### L.A. Girl Pastel Dream Auto Liner

### Choose your option

Eyeliner

### Milani The Tank Waterproof Liquid Eyeliner Black

### Choose your option

Eyeliner

### Milani Stay Put Matte 17 Hr Wear Liquid Eyeliner

### Choose your option

Eyeliner

### L.A. Colors Browie Wowie Brow Tinted Gel-Soft Brown

### Choose your option

Eyeliner

### L.A. Girl Skinny Gel Eyeliner

### Choose your option

Eyeliner

### L.A. Colors All Is Bright 5 Pcs Defined Looks Automatic Eyeliner Set

### Choose your option

Eyeliner

### Wet n Wild Megaliner Liquid Eyeliner

### Choose your option

Eyeliner

### L.A. Colors Glitter Liquid Eyeliner

### Choose your option

Eyeliner

### L.A. Girl Shock Wave Metallic Eyeliner Pencil

### Choose your option

Eyeliner

### Milani Stay Put Auto Eyeliner

### Choose your option

Eyeliner

### L.A. Colors Blister Gel Eyeliner-Black

### Choose your option

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick