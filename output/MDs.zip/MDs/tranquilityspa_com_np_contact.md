- SERVICESRelaxation MassageSignature MassageTherapeutic MassageMini TherapyLadies Beauty ServicesGentlemen Salon ServicesVastiCuppingHydroTherapy

- PACKAGESBeauty PackageSpa PackageSeasonal Package

- MEMBERSHIPSolatee MembershipTranquility Wellness Card

- ABOUTWelcome To Tranquility SpaHistoryMission And VisionTeams

- OUTLETSThe Soaltee KathmanduHotel Radission KathmanduChandragiri Hills ResortHotel SarowarHotel Crown ImperialHotel ShankerTranquility Spa - JhamsikhelKupondole

- BLOGS

- CAREERS

- CONTACT

# TRANQUILITY SPA

# Email Address

# info@tranquilityspa.com.np

# Phone Number

# +977-9802365118

# Head-Office

# Kathmandu 44600, Nepal

#### Our Associated Partners