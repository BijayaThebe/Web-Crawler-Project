✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

13 products

## Filter

- In stock11

- Out of stock2

- In stock11

- Out of stock2

primer

### Milani No Pore Zone Mattifying Face Primer

### Choose your option

primer

### Wet n Wild Photo Focus Matte Face Primer - 25 ml

### Choose your option

primer

### L.A. Girl Pro Face Primer

### Choose your option

primer

### L.A. Colors Blister Face Primer-Clear

### Choose your option

primer

### Milani Skin Quench Hydrating Face Primer

### Choose your option

primer

### Wet n Wild Prime Focus Primer Serum 30ml

### Choose your option

primer

### Wet n Wild Megalast 16h Eyeshadow Primer - 10 ml

### Choose your option

primer

### Beauty Creations Flawless Stay Grip Primer 25g

### Choose your option

primer

### Milani Conceal + Perfect Blur Out Smoothing Primer 21g

### Choose your option

primer

### Beauty Creations Flawless Stay Poreless Primer

### Choose your option

primer

### L.A. Girl Blurring Putty Primer 15g

### Choose your option

primer

### L.A. Girl Let's Chill Hydrating Primer Stick 12.2g

### Choose your option

primer

### L.A. Girl Prismatic Light Reflecting Primer 25ml

### Choose your option

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick