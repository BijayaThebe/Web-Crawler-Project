- OSHC

- STUDENT ACCOMMODATION

- NEWS & OFFER

- COUNSELOR DASHBOARD

- LOGINSTUDENT LOGIN

- STUDENT LOGIN

## University of the Sunshine Coast Student Info Session

## EventDetails

### 17th September 2025, Wednesday

### KIEC Avenue, Lalupatey Marga, Putalisadak

🎓✨ Dreaming of Australia for your higher studies?

Here’s your chance to connect with one of its fastest-growing universities — University of the Sunshine Coast (UniSC), Australia!🌞

Meet Raj Desai | Business Development Manager (South Asia, Southeast Asia & Middle East)

🌟 Why UniSC?✅ Top-quality teaching with modern facilities✅ Campuses across South East Queensland, including Sunshine Coast, Brisbane & Moreton Bay✅ Strong industry connections & practical learning opportunities✅ Supportive community for international students

💡 Get all the details on courses, scholarships, admissions, and career pathways directly from the university representative!

𝐅𝐨𝐫 𝐦𝐨𝐫𝐞 𝐝𝐞𝐭𝐚𝐢𝐥𝐬, 𝐯𝐢𝐬𝐢𝐭 𝐮𝐬 𝐚𝐭:KIEC Avenue44-05, Lalupatey Marg, Putalisadak, KTM, Nepal📞 +977 4531221, 01 4516197📍 https://bit.ly/KIEC_Avenue📩[email protected]

If you cannot attend this session, please visit nearest KIEC offices

𝐅𝐨𝐫 𝐛𝐫𝐚𝐧𝐜𝐡𝐞𝐬, 𝐲𝐨𝐮 𝐜𝐚𝐧 𝐯𝐢𝐬𝐢𝐭:🌐 www.kiec.edu.np/contact-us

🚀 Don’t miss this golden opportunity to take your first step towards studying at UniSC!

# StudyInAustralia #UniversityoftheSunshineCoast #KIEC #StudentSession #StudyAbroadDreams