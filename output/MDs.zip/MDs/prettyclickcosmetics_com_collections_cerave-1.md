✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

18 products

## Filter

- In stock14

- Out of stock4

- In stock14

- Out of stock4

Cleanser

### Cerave Hydrating Facial Cleanser 355ml

### Choose your option

Moisturizer

### Cerave Daily Moisturizing Lotion 355ml

### Choose your option

Moisturizer Cream

### Cerave Moisturizing Cream - 539 g

### Choose your option

Cream

### Cerave Moisturizing Cream - 340g

### Choose your option

Cleanser

### Cerave Acne Control Cleanser 237ml

### Choose your option

Cleanser

### Cerave Foaming Facial Cleanser - 355ml

### Choose your option

Cream

### Cerave Moisturizing Cream - 236ml

### Choose your option

Cream

### Cerave Moisturizing Cream 56ml

### Choose your option

Lotion

### Cerave Am Facial Moisturizing Lotion Spf 30 - 89ml

### Choose your option

Cleanser

### Cerave Foaming Facial Cleanser 87Ml

### Choose your option

Moisturizer

### Cerave Facial Moisturizing Lotion PM 89ml

### Choose your option

Moisturizer

### Cerave Sa lotion For Rough & Bumpy Skin 237ml

### Choose your option

Cleanser

### Cerave Foaming Facial Cleanser - 237ml

### Choose your option

Lotion

### Cerave Pm Facial Moisturizing Lotion - 60ml

### Choose your option

Cleanser

### Cerave Hydrating Facial Cleanser - 237ml

### Choose your option

Gel

### Cerave Aha & Bha Acne Control Gel - 40ml

### Choose your option

Oil

### Cerave Skin Renewing Gel oil - 29ml

### Choose your option

Moisturizer

### Cerave Baby Moisturizing Lotion 237ml

### Choose your option

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick