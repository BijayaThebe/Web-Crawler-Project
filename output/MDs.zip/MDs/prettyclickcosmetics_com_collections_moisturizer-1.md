✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

23 products

## Filter

- In stock15

- Out of stock8

- In stock15

- Out of stock8

Moisturizer

### Roc Multi Correxion� Revive + Glow Moisturizer

### Choose your option

Moisturizer

### Roc Retinol Correxion� Deep Wrinkle Daily Moisturizer spf 30

### Choose your option

Moisturizer

### Cosrx Full Fit Propolis Light Cream

### Choose your option

Moisturizer

### Cerave Daily Moisturizing Lotion 355ml

### Choose your option

Moisturizer

### Good Molecules Lightweight Daily Moisturizer 100ml

### Choose your option

Moisturizer

### Cetaphil Moisturizing Lotion 473ml

### Choose your option

Moisturizer

### Cosrx Advanced Snail 92 All in one Cream

### Choose your option

Moisturizer

### Neutrogena Hyaluronic Acid Water Gel Hydro Boost - 50ml

### Choose your option

Moisturizer

### Dermae Vitamin C Renewing Moisturizer

### Choose your option

Moisturizer

### Hempz Sensitive Skin Herbal Body Moisturizer 500 ml

### Choose your option

Moisturizer

### Cetaphil Moisturizing Cream 453gm

### Choose your option

Moisturizer

### Cerave Facial Moisturizing Lotion PM 89ml

### Choose your option

Moisturizer

### Hempz Original Herbal Body Moisturizer

### Choose your option

Moisturizer

### Cerave Sa lotion For Rough & Bumpy Skin 237ml

### Choose your option

Moisturizer

### Dermae Anti-Aging Regenerative Day Cream

### Choose your option

Moisturizer

### Skin1OO4 Poremizing Light Gel Cream 75 ml

### Choose your option

Moisturizer

### Dear Klairs Midnight Blue Calming Cream(60g)

### Choose your option

Moisturizer

### Hempz Fragrance-Free Herbal Limited Edition Daily Moisturizing Cream 500 ml

### Choose your option

Moisturizer

### Roc Multi Correxion Even Tone +Lift Daily Moisturizer Spf 30

### Choose your option

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick