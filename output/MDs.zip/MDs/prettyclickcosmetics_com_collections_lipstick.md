✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

26 products

## Filter

- In stock21

- Out of stock9

- In stock21

- Out of stock9

Lipstick

### Makeup Revolution Lasting Kiss Lipstick

### Choose your option

lipstick

### Beauty Creations Tease Me Soft Matte Lipstick

### Choose your option

Lipstick

### J. Cat Beauty Lip Lock Mask Proof Liquid Lipstick

### Choose your option

Lipstick

### Wet n Wild Megalast High-Shine Brillance Lipstick

### Choose your option

Lipstick

### Wet n Wild Megalast Matte Lipstick

### Choose your option

Lipstick

### J. Cat Beauty Amaze Me Tinted Lip Crayon

### Choose your option

Lipstick

### Prettyclick Bullet Lipstick 3g: Beloved

### Choose your option

Lipstick

### Prettyclick Bullet Lipstick 3g: Stunner

### Choose your option

Lipstick

### Milani Color Fetish Hydrating Lip Stain

### Choose your option

Lipstick

### Prettyclick Bullet Lipstick 3g: Ruby Flame

### Choose your option

Lipstick

### Prettyclick Bullet Lipstick 3g: Dream Girl

### Choose your option

lipstick

### Milani Color Fetish Matte Lipstick

### Choose your option

lipstick

### Milani Color Statement Lipstick Matte Beauty 69

### Choose your option

Lipstick

### Prettyclick Lip Crayon: Girl Crush

### Choose your option

Lipstick

### Prettyclick Lip Crayon: Sincity

### Choose your option

Lipstick

### Prettyclick Bullet Lipstick 3g: City Girl

### Choose your option

Lipstick

### Milani Color Statement Lipstick Matte Tender 77

### Choose your option

Lipstick

### Prettyclick Lip Crayon: Heartbreaker

### Choose your option

lipstick

### L.A Girl Stay & Play Long Wear Matte Lip Crayon

### Choose your option

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick