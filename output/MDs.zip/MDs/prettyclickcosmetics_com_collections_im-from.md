✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

10 products

## Filter

- In stock10

- Out of stock0

- In stock10

- Out of stock0

Toner

### I'm From Black Rice Toner 150ml

### Choose your option

Toner

### I'm From Black Rice Toner 30ml

### Choose your option

Cream

### I'm From Rice Cream 50g

### Choose your option

Face mask

### I'm From Rice Mask 110g

### Choose your option

Serum

### I'm From Rice Serum 30ml

### Choose your option

Toner

### I'm From Rice Toner 150ml

### Choose your option

Toner

### I'm From Rice Toner 30ml

### Choose your option

Pad

### I'm From Rice Toner Pad 140ml

### Choose your option

Cleanser

### I'm From Rice Whip Facial Cleanser 150ml

### Choose your option

Cleanser

### I'm From Rice Whip Facial Cleanser 30ml

### Choose your option

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick