✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

33 products

## Filter

- In stock33

- Out of stock11

- In stock33

- Out of stock11

Setting Spray

### Milani 16HR Make It Dewy Setting Spray

### Choose your option

Foundation

### Milani Conceal + Perfect 2 In One Foundation + Concealer

### Choose your option

Mascara

### Milani Highly Rated Anti Gravity Mascara - 115

### Choose your option

primer

### Milani Conceal + Perfect Blur Out Smoothing Primer 21g

### Choose your option

Powder

### Milani Conceal+Perfect Shine-Proof Powder

### Choose your option

Eyeliner

### Milani Stay Put Matte 17HR Wear Liquid Eyeliner Waterproof - 150

### Choose your option

Highlighter

### Milani Baked Highlighter

### Choose your option

primer

### Milani No Pore Zone Mattifying Face Primer

### Choose your option

Blush

### Milani Cheek Kiss Blush + Glow Liquid Blush 10ml

### Choose your option

Lipstick

### Milani Color Statement Lipstick Matte Kiss 72

### Choose your option

Lipstick

### Milani Color Statement Lipstick Matte Dreamy 80

### Choose your option

Lipstick

### Milani Color Fetish Hydrating Lip Stain

### Choose your option

Setting Spray

### Milani Make It Last Original - Natural Finish Setting Spray

### Choose your option

Blush

### Milani Cheek Kiss Cream Blush

### Choose your option

Eyeliner

### Milani The Tank Waterproof Liquid Eyeliner Black

### Choose your option

Mascara

### Milani Highly Rated Lash Extensions Mascara

### Choose your option

Blush

### Milani Baked Blush

### Choose your option

primer

### Milani Skin Quench Hydrating Face Primer

### Choose your option

Brow Pomade

### Milani Stay Put Brow Color

### Choose your option

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick