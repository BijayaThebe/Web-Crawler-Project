- SERVICESRelaxation MassageSignature MassageTherapeutic MassageMini TherapyLadies Beauty ServicesGentlemen Salon ServicesVastiCuppingHydroTherapy

- PACKAGESBeauty PackageSpa PackageSeasonal Package

- MEMBERSHIPSolatee MembershipTranquility Wellness Card

- ABOUTWelcome To Tranquility SpaHistoryMission And VisionTeams

- OUTLETSThe Soaltee KathmanduHotel Radission KathmanduChandragiri Hills ResortHotel SarowarHotel Crown ImperialHotel ShankerTranquility Spa - JhamsikhelKupondole

- BLOGS

- CAREERS

- CONTACT

# CurrentJob
                    Openings

Do you think you are a good fit? Apply now. We would love to meet you.

### Manager

### Apply

### Sr Spa Manager

### Apply

#### Our Associated Partners