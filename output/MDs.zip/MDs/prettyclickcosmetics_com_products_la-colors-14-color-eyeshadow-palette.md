✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

# L.A.  Colors 14 Color Eyeshadow Palette

## L.A.  Colors 14 Color Eyeshadow Palette

Vendor:LA COLORS

Type:Eyeshadow

Earn 5% prettyclick reward points on every purchase

- 100% Authentic

Available in stock

Take your looks on a trip with the L.A. COLORS Coastal Chill Eyeshadow collection. Inspired by your next tropical vacay, these 14-color eyeshadow palettes are packed with colorful (yet super wearable) shades in a mix of matte and shimmer finishes. Lagoon blues, paradise purples, sunset oranges, and rose gold pinks all play nice together creating your signature out of office look. You’ll want to snap a selfie with the color coordinating packaging that matches your getaway vibes. This collection captures paradise in a palette.

- 14-color eyeshadow palette

- Matte and shimmer finishes

- Blendable, long-wearing formula

- Cruelty-free

- Free Delivery for orders over Rs 3500

- Exchange within 7 days if the sealed is not opened

### L.A.  Colors 14 Color Eyeshadow Palette

## Customer Reviews

La Colors 14 Color Eyeshadow Palette

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick