✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

# Dear Klairs Freshly Juiced Vitamin E Mask 90g

## Dear Klairs Freshly Juiced Vitamin E Mask 90g

Vendor:Dear klairs

Type:Mask

Earn 5% prettyclick reward points on every purchase

- 100% Authentic

Low stock

The Freshly Juiced Vitamin E Mask hydrates the skin and enhances the effects of Vitamin C products. It’s formulated with Niacinamide and Adenosine, which gives various skin-improving effects, and can also be used as a gel-type moisturizing cream.– Primary Skin Irritation Test completed– Primary Skin Irritation Test for Sensitive Skin completed– Skin Transparency Improvement Test completed– 24-hours Continuous Hydrating Test completed

Cruelty free

Vegan friendly

Moisturizer

Water-oil balance

Aqua (Water), Glycerin, Butylene Glycol, Niacinamide, Tocopheryl Acetate, Carrageenan, Betaine, Algin, Gellan Gum, Glucomannan, PEG-60 Hydrogenated Castor Oil, Acrylates/C10-30 Alkyl Acrylate Crosspolymer, Arginine, Ethylhexylglycerin, Chlorphenesin, Hydrogenated Lecithin, Rubus Fruticosus (Blackberry) Fruit Extract, Centella Asiatica Extract,1,2-Hexanediol, Adenosine, Phragmites Communis Extract, Salicornia Herbacea Extract, Ceramide NP, Sodium Hyaluronate, Citrus Limon (Lemon) Peel Oil, Lavandula Angustifolia (Lavender) Oil, Citrus Aurantium Dulcis (Orange) Peel Oil, Pelargonium Graveolens Flower Oil, Cananga Odorata Flower Oil, Eucalyptus Globulus Leaf Oil

- Free Delivery for orders over Rs 3500

- Exchange within 7 days if the sealed is not opened

### Dear Klairs Freshly Juiced Vitamin E Mask 90g

## Customer Reviews

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick