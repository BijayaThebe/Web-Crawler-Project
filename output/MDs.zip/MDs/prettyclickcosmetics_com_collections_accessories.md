✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

56 products

## Filter

- In stock34

- Out of stock26

- In stock34

- Out of stock26

Eyelash

### Cala 3D Faux Mink Lashes

### Choose your option

Eyelash

### Cala 3D Faux Mink Multi-Dimensional Lashes

### Choose your option

Makeup Brush

### Cala Eye Need It Essential Brush Kit

### Choose your option

Beauty Blender

### L.A.  Colors I'm Latex Free Blending Sponge

### Choose your option

Makeup Brush

### Cala Studio Master Concealer Brush-76306

### Choose your option

Makeup Brush

### Prettyclick 5 Pcs Makeup Brush Set

### Choose your option

Makeup Brush

### Cala Blending Brush-76311

### Choose your option

Puff

### Cala Powder Puff (Big-70921)

### Choose your option

Blending Sponge

### Cala Urban Studio Ultimate Blending Sponge- Black(76257)

### Choose your option

Puff

### Cala Powder Puff (Small-70920)

### Choose your option

Beauty Blender

### Cala Urban Studio Ultimate Blending Sponge-Pink(76253)

### Choose your option

Blending Sponge

### Cala Urban Studio Ultimate Blending Sponge-Purple(76254)

### Choose your option

Makeup Brush

### Cala Fan Brush-76305

### Choose your option

False Eyelashes

### Cala Volt Premium Lashes

### Choose your option

Makeup Brush

### La Colors Large Powder Brush

### Choose your option

Makeup Brush

### La Colors Blush Brush

### Choose your option

Makeup Brush

### La Colors Flat Kabuki Brush

### Choose your option

Makeup Brush

### L.A. Colors Pro Series Duo Brow & Liner Brush

### Choose your option

Makeup Brush

### Cala Studio Master Angled Contour Brush-76302

### Choose your option

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick