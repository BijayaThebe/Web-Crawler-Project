- OSHC

- STUDENT ACCOMMODATION

- NEWS & OFFER

- COUNSELOR DASHBOARD

- LOGINSTUDENT LOGIN

- STUDENT LOGIN

# UnivesitiesRepresent by

## Find University to Study Abroad

#### Australia

#### United States

#### United Kingdom

#### Europe

#### New Zealand

#### Canada

#### japan

#### Ireland

## Study abroadfrom

## Study abroadfrom

### 250k

### Congratulations

### Congratulations

### Post-Study Counseling

## Study abroadfrom

### 250k

### Congratulations

### Post-Study Counseling

## OurLocation

### Dang

### Butwal

### pokhara

### Chitwan

### Birjunj

### KTM

### Lalitpur

### Itahari

### Biratnagar

### Nepalgunj

### Hetauda

## OurLocation

### Dang

### Butwal

### pokhara

### Chitwan

### Birjunj

### KTM

### Lalitpur

### Itahari

### Biratnagar

### Birtamode

### Nepalgunj

### Hetauda