- SERVICESRelaxation MassageSignature MassageTherapeutic MassageMini TherapyLadies Beauty ServicesGentlemen Salon ServicesVastiCuppingHydroTherapy

- PACKAGESBeauty PackageSpa PackageSeasonal Package

- MEMBERSHIPSolatee MembershipTranquility Wellness Card

- ABOUTWelcome To Tranquility SpaHistoryMission And VisionTeams

- OUTLETSThe Soaltee KathmanduHotel Radission KathmanduChandragiri Hills ResortHotel SarowarHotel Crown ImperialHotel ShankerTranquility Spa - JhamsikhelKupondole

- BLOGS

- CAREERS

- CONTACT

# OUR SERVICES

Opening Hours: 6:00am-10:00pmTahachal Marg,Kathmandu+977-9801076721soaltee.tranquilityspa@gmail.com

- Opening Hours: 6:00am-10:00pm

- Tahachal Marg,Kathmandu

- +977-9801076721

- soaltee.tranquilityspa@gmail.com

# Services

##### Starting From Rs
                        5000-10000/-

#### Our Associated Partners