- SERVICESRelaxation MassageSignature MassageTherapeutic MassageMini TherapyLadies Beauty ServicesGentlemen Salon ServicesVastiCuppingHydroTherapy

- PACKAGESBeauty PackageSpa PackageSeasonal Package

- MEMBERSHIPSolatee MembershipTranquility Wellness Card

- ABOUTWelcome To Tranquility SpaHistoryMission And VisionTeams

- OUTLETSThe Soaltee KathmanduHotel Radission KathmanduChandragiri Hills ResortHotel SarowarHotel Crown ImperialHotel ShankerTranquility Spa - JhamsikhelKupondole

- BLOGS

- CAREERS

- CONTACT

# OUR OUTLETS

## The Soaltee Kathmandu

- Opening Hours:
                            6:00am-10:00pm

- Tahachal Marg,Kathmandu

- +977-9801076721

- soaltee.tranquilityspa@gmail.com

## Radisson Hotel And Residences Kathmandu

- Opening Hours:
                            7am- 9pm

- Lazimpat

- +977 980-2021286

- info@tranquilityspa.com.np

## Tranquility Spa- Ramada By Wyndham Kathmandu

- Opening Hours:
                            9am-9pm

- Dhumbarahi, Kathmandu

- 9801034467 / 9849034467

- info@tranquilityspa.com.np

## Chandragiri Hills Resort

- Opening Hours:
                            6:00am-10:00pm

- Chandragiri,Kathmandu

- +977 980-1076724

- tranquilityspachandragiri@gmail.com

## Hotel Sarowar

- Opening Hours:
                            8am- 10pm

- Pokhara

- +977-9802021282

- info@tranquilityspa.com.np

## Hotel Crown Imperial

- Opening Hours:
                            8am- 10pm

- Ravi Bhawan

- +977-9801076730

- tranquilityspaatcrownimperial@gmail.com

## Hotel Shanker

- Opening Hours:
                            8am- 9pm

- Shanker Hotel, Lazimpat

- +977-9801021265

- tranquilityshanker@gmail.com

## Tranquility Spa-Jhamsikhel

- Opening Hours:
                            8am- 9pm

- Jhamsikhel

- +977-9802021276

- info@tranquilityspa.com.np

## Kupondole

- Opening Hours:
                            8am- 9pm

- Kupandole

- +977 980-2021269

- tranquilityspa.kupandol@gmail.com

#### Our Associated Partners