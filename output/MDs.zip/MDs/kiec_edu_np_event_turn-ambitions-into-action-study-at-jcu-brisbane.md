- OSHC

- STUDENT ACCOMMODATION

- NEWS & OFFER

- COUNSELOR DASHBOARD

- LOGINSTUDENT LOGIN

- STUDENT LOGIN

## Turn Ambitions into Action – Study at JCU Brisbane

## EventDetails

### 28th August 2025, Thursday

### KIEC Avenue, Lalupatey Marga, Putalisadak

🎓 Want to study inAustralia? Start withJames Cook University, Brisbane!

📌 MeetVaibhav Kwatra– Senior Manager, South Asia atJames Cook University– and get all your questions answered!

💼 Why James Cook University (Brisbane)?✅ One of Australia’s top universities with a global reputation✅ Industry-aligned programs with real-world focus✅ Campuses in vibrant cities including Brisbane✅ Scholarships available for international students✅ Strong graduate outcomes and support services

📅Date:28th August 2025 (Thursday)🕐Time:12:30 PM – 1:30 PM📍Venue:KIEC Avenue, Putalisadak, Kathmandu

𝐅𝐨𝐫 𝐦𝐨𝐫𝐞 𝐝𝐞𝐭𝐚𝐢𝐥𝐬, 𝐯𝐢𝐬𝐢𝐭 𝐮𝐬 𝐚𝐭:KIEC Avenue44-05, Lalupatey Marg, Putalisadak, KTM, Nepal📞 +977 01-5971526, 4531221, 4010567📍https://bit.ly/KIEC_Avenue📩[email protected]

If you cannot attend this session, please visit your nearest KIEC office.

𝐅𝐨𝐫 𝐛𝐫𝐚𝐧𝐜𝐡𝐞𝐬, 𝐲𝐨𝐮 𝐜𝐚𝐧 𝐯𝐢𝐬𝐢𝐭:🌐www.kiec.edu.np/contact-us

👨‍🎓 Whether you’re planning for undergraduate or postgraduate study, this is your chance to get direct guidance from the university itself!

#JamesCookUniversity #StudyInAustralia #JCUBrisbane #KIEC #MeetTheRep #StudyAbroadNepal #AustralianUniversities #Scholarships #CareerAbroad #NepalToAustralia