✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

# L.A. Colors Jelly Cool Tinted Blush Stick

## L.A. Colors Jelly Cool Tinted Blush Stick

Vendor:LA COLORS

Type:Blush

Earn 5% prettyclick reward points on every purchase

- 100% Authentic

Available in stock

What It Is:

Innovative jelly formula, imbued with a hydrating formula that offers a trendy cooling effect for your skin. Available in 3 blush colors: Icy Cherry, Icy Berry and Icy Melon plus a glitter stick in Extra Icy. These jelly sticks are made to glide onto your skin providing a wash of color or extra shine.

What It Does:

- Glycerin & Sodium Hyaluronate: Adds moisture

- Cooling effect

Why You'll Love It:

Spruce-up your skin and makeup routine with these refreshing jelly sticks that offer leading-edge cooling effects and bouncy texture. The crisp iciness will invigorate your skin and body. Available as a tinted blush and a clear, glitter jelly, these sticks are deliciously scented and deliver subtly sheer coverage for your face and body.

- Cruelty-free

- Water-based

- Lightly scented

- Lightweight

- Innovative jelly texture

How To Apply

Apply to skin in thin swipes, layer as desired.

- Free Delivery for orders over Rs 3500

- Exchange within 7 days if the sealed is not opened

### L.A. Colors Jelly Cool Tinted Blush Stick

## Customer Reviews

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick