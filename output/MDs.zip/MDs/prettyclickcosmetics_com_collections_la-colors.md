✌🏼 Free delivery on all orders of Rs.3500 and more.

## Language

- English

- नेपाली

- Facebook

- Instagram

93 products

## Filter

- In stock51

- Out of stock56

- In stock51

- Out of stock56

Mascara

### L.A. Colors Biggie Lash Mascara

### Choose your option

Nail Polish

### Color Craze Nail Polish

### Choose your option

Nail Polish

### Color Craze Shimmer Gel Nail Polish

### Choose your option

Nail Polish

### Diamond Crush Nail Polish

### Choose your option

Nail Polish

### Glitter Vibes Nail Polish

### Choose your option

Nail Tip

### L.A. Colors 24 Pcs Artificial Nail Tips

### Choose your option

Sponge

### L.A. Colors 3 Pcs Precision Mini Sponge

### Choose your option

Artificial nail

### L.A. Colors All Is Bright 28 Pcs Shine Artificial Nail Tips

### Choose your option

Eyelash

### L.A. Colors All Is Bright 5 Pcs Pretty Wispy Eyelash Set

### Choose your option

Eyeshadow

### L.A. Colors 12 Colors Too Precious Eyeshadow

### Choose your option

Nail Tip

### L.A. Colors 13 Piece Gel Nails On! Nail Tips And Glue Kit

### Choose your option

Lashes

### L.A. Colors 3D Faux Mink Lashes

### Choose your option

Moisturizer Cream

### L.A. Colors All Is Bright 5 pcs Beary Shiny Moisturizer Set

### Choose your option

Lipliner

### L.A. Colors All Is Bright 5 Pcs Defined Lips Automatic Lip Liner Set

### Choose your option

Eyeliner

### L.A. Colors All Is Bright 5 Pcs Defined Looks Automatic Eyeliner Set

### Choose your option

Makeup Brush

### L.A. Colors Angled Eyeshadow Brush

### Choose your option

Blush

### L.A. Colors Blush Up Cheek & Lip Cream

### Choose your option

Eyeshadow

### L.A. Colors Color Block 10 Color Eyeshadow Palette

### Choose your option

Lashes

### L.A. Colors Dramatilash False Eyelash Kit

### Choose your option

### Customer Service

Mon-Sat, 9am-6pm

### Call Us

9840028478

### Get in Touch

Support@prettyclickcosmetics.com

## Your cart(0)

Your cart is currently empty.

Not sure where to start? Try these collections:

- Milani

### Milani

- La Girl

### La Girl

- Wet and Wild

### Wet and Wild

- Cosrx

### Cosrx

- Skin1004

### Skin1004

- La Colors

### La Colors

- Roc Skincare

### Roc Skincare

- Good Molecules

### Good Molecules

##### Order note

##### Coupon

### Product Comparison

- Choosing a selection results in a full page refresh.

- Opens in a new window.

Nice!

loved it

I love it

long lasting

best decision i have ever made was trying out Beauty of Joseon Matte Sun Stick