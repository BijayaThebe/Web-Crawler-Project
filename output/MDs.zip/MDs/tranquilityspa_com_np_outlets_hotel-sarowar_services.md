- SERVICESRelaxation MassageSignature MassageTherapeutic MassageMini TherapyLadies Beauty ServicesGentlemen Salon ServicesVastiCuppingHydroTherapy

- PACKAGESBeauty PackageSpa PackageSeasonal Package

- MEMBERSHIPSolatee MembershipTranquility Wellness Card

- ABOUTWelcome To Tranquility SpaHistoryMission And VisionTeams

- OUTLETSThe Soaltee KathmanduHotel Radission KathmanduChandragiri Hills ResortHotel SarowarHotel Crown ImperialHotel ShankerTranquility Spa - JhamsikhelKupondole

- BLOGS

- CAREERS

- CONTACT

# OUR SERVICES

# Services

##### Starting From Rs
                        6500-10500/-

##### Starting From Rs
                        4000-9500/-

##### Starting From Rs
                        6000-1000/-

##### Starting From Rs
                        8000-10000/-

##### Starting From Rs
                        6000-10000/-

#### Our Associated Partners